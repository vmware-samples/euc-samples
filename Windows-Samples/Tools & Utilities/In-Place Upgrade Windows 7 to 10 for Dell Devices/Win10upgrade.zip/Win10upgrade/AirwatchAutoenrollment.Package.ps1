﻿#------------------------------------------------------------------------
# Source File Information (DO NOT MODIFY)
# Source ID: dd23de76-345a-40ba-9033-813aeebea0ac
# Source File: D:\DeplymentShare\Win10upgrade\AirwatchAutoenrollment.psf
#------------------------------------------------------------------------
#region File Recovery Data (DO NOT MODIFY)
<#RecoveryData:
Dj0AAB+LCAAAAAAABADtW2lzm1jT/e4q/weXv5I3bAJBVZIqsYMAgdCC+PIWq9iR2OHXP8hOJjMT
x7aSmdRMjeOKDfj27eae0w3te/Rh7btF65cDY9f23XRQRUX+8R55D99/ur25u/uwKqNjlNspF6W+
amf+p0VUdnbthoumLvy8LNI08/P6/akKPoDfDH6cwol9t76rh5P/8d4YqtrP3u+j3Cu66j1XlNnj
93d3T/3q3d3uc0yz99Dl690d3aR1U/ofc7+pSzt9d6c1Thq5S3/YFImff3TmcxtzMRwm0ZkPEeT9
XT6F8vE+mOabgt9/CZ79HPz9nRtGqVdOpvd0kdfT1erx5qfYtbI4+WU9fJ7jYme4duoz0XTXl7im
ofi7Oxj9AH4Z+pKpUnj+/Sdu8vSiDWW7CV2kRXn/aeHWUevT9qmenG78/mVjOo0mYIxonLwRJPzu
bgaRLxpdULv/9L2letH8Etj9py+mdxfb/2N/I8m35i9TQ7NzP/3buXG6eIGfY8Kz4FBNXRe5EB3D
dPr/7X1+aywXrn1B8v7TFDUyf4XFIzKPgb5i+BfcsXd3KPYt7k9AZzti7vn9FNFTo19G6nER/nao
nAc3vJ/7pV37X6hmuGX0PHzPAsj4/slIBiptvuX4U6aX7L3/ZPjHwr/biu/uiPcIdnoK9+eQn+PI
BA70FPjfg//7N/+qSR5JAUPE5PcpTjzHCpR4ncFDBfgS4d1vpeAS4ytXaFv5u6hq7NSoh9T/HUqc
nVbfwYdtp/rytfC5yXNr9f8PIz6AD0bfm0Upmsp/eaqvw/483/Q4fMiZa3JItp1fUO3SixfNrqqu
KL2fyBoYQafiBc8n/r+OxNTkzy8fYJ3QjHrfQ5kfyjfy6mTDIOQS67fP6e8n2x+W6Yr8Ih5W5dr0
et0KPqbXM0H9w1k35XZ5Of2PsG6O/hDpvqzS3046/ArSPRPUP5x0fFk0py+gqP8d9j3UPBh+6n3u
Wfp9s17XvFzMkB8hInbNy8UlvLsv8d39Ozlp+OXUbf9HiDgnf4iHj2v0txfB2RXc+25IP0K3X9jb
Ij/BNL60hysBn8KFr+lrHmO8BmlyKjP4tVB/p4V5BVKRe1l7quj/frgeXTlF/8LfI566VbYsi1LM
7KP/x3HTSCrK7XL4FO2o1bqDlvyxWEz/VGMbstvjdKRAl/OQXojTDwbey7FwuUDxHrXZsouFzGs0
2IeUfrmadgaXjrc30+Gq7abxJUGtFruNNF2gjVRas9zW5+Y1UgDazt3uKJABXHjndMHM2Jp4IfJ0
WZ8P+95YdrLRH7b4ub+9qRyBopfWUteRrFas6ABprLg0stPRXifcIqQWR8mmdXZxTEMA4Mg5NOe9
HpTn56WWqVhrxofRInBPQbXV7Y1H4JYPcI7YQ3igoYWvWiG/Cmdwxh5wId4f1vGrr93e+IxVgauN
wOC9W9nlKRCUzgdtr0GDtm19n9rCYNSEMzXr3FW+Lhy+UxCsBCBFgIhmp6kSLB1AuIXhBrm9aaHf
RhMEqI/z+TiOfYaO2YjrnR+Z835W+anCN4I1DQCnY41doxrYAHqoniCpQFZWj2RhRii3NyPcSRqY
J50mxH0PYoCxUs+KRNK9T5KeE2ywGeEHcwLQQYA8sI3oQhoIIqHHIjOHBAWctBsR68A5gKO3Nyg4
FzgYcCudH9tgyFNYVYW87E4ICMxdtEUDh1yS6m4vyzMw9pHW4/cy3CL+MmUZGQWQppp7wJzAGSK4
vWEdHMKN3b4I7Q5Q121ey7MxQgPSptNlpltKq44jiFJbzFluBdgx5yUEefsShsZsG5t5WWZ0dyi4
hgmd25uNSqaRZtYBmflqApUbqdbIZu5lAwciPQ8ftMpe8m4jn2AYGEYH8ndYRaacGtadLCeFK8cp
tvO0QaindRPGfrbVjkSb52MOIYfCFMEDMYuhtbBkY7Nb0aCabRQUXZebmZfJMoIlbIJ7q2p3FgGE
SkcQnGsrhSrC9PYGt9zG3Jf4rGeOFRJo6gnuaXkh+duzE2MnqUc4E2OcgFQ8ymlnAdhQgpicqKyr
jgSqlgdLThOTbkj84N7e2P1ipw+GwPTgvjePGyxNmZwPpRZuQVWVXAI8KSvX59lhODYLEYzO6kGC
Mkfen/mJlDa3RbJhk+1RqCSmPD37dFebCb1Ea5CvHZ0gKAkHlRVj8bx8rvYbeJlxIbuwulInnUW1
TnC/NYp1HxtqvW/XOaaKmzE2thV8exPyHjSLTHybkFApgH0RmXZgHVdjf0R8jOI4gSqUkfIQJYuA
3g60HMU7kWUUJHDhqpsrrXxcdIC3Qv0pT7sSIwGoVERNQlESSeP9eSWPUkozFFPJSWvvdg1OoJ1i
ieuoQhkNbQ4mbcf92YUTMPKUc+mRK8RZu3F7e5PFHWPnpq3DgNCPnaOWnW6YYXb2zpK36KXZLlEc
FRnS7eYAHSFXU5blYKkktkOgJYiFfXBWw2SkOrk43d6Ua9FepkSzocX9UtmOTcNbakPsGKwOjpFh
quZagGdDI+wQ1FaFKFbtA1MB1VEIFOY0HgyhXo8iu0AQZX5742wpTN+WsMMaZM8rOU8zoWpLfQwd
pzTSR4WId5Ka7gQ3FnGg1KkZnyer7pCXbDkcUoHjGTk9I6YMg83tTdSDFSIL8ShlfLDc0xtqKrk0
5BtzX7Nmh6qPxJGvj8fcKtxgNTuceROoG3M41Gp73C5F7tDq2CnR96LG3d6Q/G6ZLMPtfoZ28RIC
NJjWYb+L0P0yZUiVYKAQOuL6MqFm0fTAWI/ume6O2tberqeqK3WhbOXFml0uoNS4vbFSCBcMbdfz
SVxCVb5aA7CMQJwLBEqDMuGsbeYoGWShha+rnecj1rg+CnuuWKXbhF8Uw4Cpwbw8XPJo4ptemVZN
9icn3mpsKybdiB+U6Gw01EaQs7Wbtn6btFtfM3cwcCSa1ug9tSIMsKxmaBGwCSzVQGoaK3yq5AN0
dCBgYx3zyhTidOhXQ+d4FZLk6YihII5CRJzolmif8B3D6RFj4zq7FREGYC1tLNJIMtfYknP1fbSf
qiVFYYEzW+8UbIRwkZmHi9MSSxAgZUal7jk/2efzwd/wluTy5E7qWGwtel6SKMdantdxvpUCrV41
EGpRtzdyJaT7TF4JS1c/Y06ZZmLekFFb9UFJnHqyt+V6vQzUCvSQ6X4HVxHoU0yI0d4hoZTWodPo
mTq6wag8mWqvyMRWQMBnVNbO9C5lDdPYakolFK6+KK0WxNvmfNqZyKlCnFoGMF+T602ALEomitY7
DmwMXMKJIt55U+0NYn3EIXF36tUMKRkCkbkY0gn2KCzojYTliCNuujM2QcCv7c3gA+jSsbocQwOt
xTcoKfnGTtq6Rb8RpszSANg2Y7GvASUamJOigW01B3NqiyZedqByplAMWDCaY9YOpTxXaoYj8zjB
60pfEMvcO6WI6J6gCeNwc3uzKrPMZNlBx7hRFbyyxzqSnBtAyEh1Xu2JYaHCOUxFClN2KZi1tNvp
sl9XKLA5szA4jktsXS3dYcGsp9nEusJKyTYRqVEDJY8AUqlnvHdmQUbZ9xup0wL2GLa8MjtS7KqD
CjmOV3nC45mNJZjZbjgmgAOZotf99FaDmpIlS1Q5zDeSNd9LncitD1a78iTWZJIMwne+vlsMsG84
ycWD0UsqGI1sVI56HA4jAUEh2tKAgEH27U2z8bROXm2lNmtxHaRj37AKQp0C92OrGcoZlyM5Giju
cUs1Azq4ZSKN5Hm+cfRseob4vlJJy228yngduL0h5qGEJxDnS9S44vY+ZLKL7dLdDhGTTlV6aEPA
r7cNccAPFR8VhAHsTwxucDOH39UrcICV9XoGOQMj9xOmFczrqr5lfMsq1zAtrOVMqmiHqip/vz6E
RmxHAhHB9fTUJBXEncg6ZvbKIih4rrPNaiLI4bDccyJyCPEp6zfV2k796LinzJob+CFzu5kA99Im
0HZCwjcmR6O4Pzc1IATPVEyTotOcfKbzKpdtGs7Cea4d9yUqdOKUWd48Nqx+H3F7MQ9N/yDhWDbU
4SjSKAln05OHVSJVadPEAmaVIa2QIOB8QVVJhBYkXovPuMoKchnO8aki0Ww+zH009WoQ1VIAYKOG
FqtNK9BBSJj4LNRPPI6QAKVjjSNw5eFgIWAM50m6wJFAPELIKZXqoZsdduzEt3iUdzOmmI2CWi/c
aKLGGneb09KCxZmoQ0WKYZXPFBUxkzgpbhoMtJabVNqymNdWZ4Onob4+7BKt2EwVqQxUUd+GwbZK
FyYNaofVfrkznfSQ4mZ9XIC9PL2wgqalLLn5Rk67I7fDDVAuDRIeFohQjwYzWOLWXpy1KTaCQkE3
7bMZEBlnNSKRnBg5tkY5bj42bFK1GdEnHZu74rYS69WYHgDX5gV7uaJIwHGpcw8dmnWxQqvF9HTe
E9gB6PouEqsK6q2FuEv0rTUugAZlxTzRZjB0oFtggaonFsIor+LambM/lOd9zS1MTAMXrNYel77n
h930NmjqBD4uFI8ZS2XRQ9qq6hhhugYy8AHZJAHIJUxnKypg25euZcGm3CYxGj2j6Q/g54boD+3U
U+3ht13WQ4P1tdn93BAypd1F+fE9FdWZfXrtVHlUR3b61rK9tWxvLdtby/bWsr21bG8t21vL9tay
vbVsby3bW8v21rL9RS3b124NfXcHP73T+N3Nya87cq+0+yyFIB/0na+0eXFD+kkToy5Ozwoj/7wt
/U/TQVyryH96JR7E9Q+Lvim/I+F9WdcAI6f63V11EUh8pIr0acnfU9OU/ued8n0Y1a/1/pWRODpx
En0tt36nj3iVRP85hiLw98U6zzL0aUXbT38e4EnG/oiyYh254cX3L9mw/yzGrKcCca3K4s/6VOx1
Gogvoomvjq9RaMHk5Ola+fc18tTfg/mXCGV+JZyPCp+fA/NB7zR73RI/YvnV6xVIIjP8B5C8Ru70
r0ay+SxY/Uks0Wvz8vd+r0ETQ34AzWsUvP9qNNPjz2P5KIi9KjG/uv3bS+w1GthroPzD6R9PFlOf
l03L71dfxn6+MnzKKrco08j5CyD8AP4265+9PJLmV/j4y4n5ssfLZ2p/jaPHracf8QWhARbMAxj2
MMhG7Zd9mVn6S+6Jnl6r/3pHv50+Uv4D+PvPP3/6H+g6n3UOPQAA#>
#endregion

<#
    .NOTES
    --------------------------------------------------------------------------------
     Code generated by:  SAPIEN Technologies, Inc., PowerShell Studio 2017 v5.4.136
     Generated on:       4/4/2017 8:45 AM
     Generated by:       jhandy@vmware.com
    --------------------------------------------------------------------------------
    .DESCRIPTION
        GUI script generated by PowerShell Studio 2017
#>


#----------------------------------------------
#region Application Functions
#----------------------------------------------

#endregion Application Functions

#----------------------------------------------
# Generated Form Function
#----------------------------------------------
function Show-AirwatchAutoenrollment_psf {

	#----------------------------------------------
	#region Import the Assemblies
	#----------------------------------------------
	[void][reflection.assembly]::Load('System.Windows.Forms, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089')
	[void][reflection.assembly]::Load('System.Data, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089')
	[void][reflection.assembly]::Load('System.Drawing, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a')
	#endregion Import Assemblies

	#----------------------------------------------
	#region Generated Form Objects
	#----------------------------------------------
	[System.Windows.Forms.Application]::EnableVisualStyles()
	$formAirWatchAutoEnrollme = New-Object 'System.Windows.Forms.Form'
	$panel1 = New-Object 'System.Windows.Forms.Panel'
	$buttonGenerateAirWatchScri = New-Object 'System.Windows.Forms.Button'
	$labelPassword = New-Object 'System.Windows.Forms.Label'
	$labelUsername = New-Object 'System.Windows.Forms.Label'
	$labelGroupLocationName = New-Object 'System.Windows.Forms.Label'
	$labelServer = New-Object 'System.Windows.Forms.Label'
	$panel2 = New-Object 'System.Windows.Forms.Panel'
	$picturebox1 = New-Object 'System.Windows.Forms.PictureBox'
	$labelAirWatchAutoEnrollme = New-Object 'System.Windows.Forms.Label'
	$passwordtbox = New-Object 'System.Windows.Forms.RichTextBox'
	$Servertbox = New-Object 'System.Windows.Forms.RichTextBox'
	$usernametbox = New-Object 'System.Windows.Forms.RichTextBox'
	$lgnametbox = New-Object 'System.Windows.Forms.RichTextBox'
	$InitialFormWindowState = New-Object 'System.Windows.Forms.FormWindowState'
	#endregion Generated Form Objects

	#----------------------------------------------
	# User Generated Script
	#----------------------------------------------
	$Servertbox.Text = $Server
	$lgnametbox.Text = $lgname
	$usernametbox.Text = $username
	$passwordtbox.Text = $password
	
	
	$buttonGenerateAirWatchScri_Click={
		#TODO: Place custom script here
		
			
		$original_file = '..\Win10upgrade\AirwatchAgenttemp.cmd'
		$destination_file = '..\Win10upgrade\AirwatchAgent.cmd'
		(Get-Content $original_file) | Foreach-Object {
			$_ -replace "yoursvrname", $Servertbox.Text `
			-replace "yourlgusrname", $lgnametbox.Text `
			-replace "yourusrname", $usernametbox.Text `
			-replace "yourpwd", $passwordtbox.Text `
			
		} | Set-Content $destination_file -en ASCII
		
		}
	
	
	$buttonGenerateAirWatchScri_MouseClick=[System.Windows.Forms.MouseEventHandler]{
	#Event Argument: $_ = [System.Windows.Forms.MouseEventArgs]
		#TODO: Place custom script here
		$buttonGenerateAirWatchScri.Text = "Script Created"
	}
	
	# --End User Generated Script--
	#----------------------------------------------
	#region Generated Events
	#----------------------------------------------
	
	$Form_StateCorrection_Load=
	{
		#Correct the initial state of the form to prevent the .Net maximized form issue
		$formAirWatchAutoEnrollme.WindowState = $InitialFormWindowState
	}
	
	$Form_Cleanup_FormClosed=
	{
		#Remove all event handlers from the controls
		try
		{
			$buttonGenerateAirWatchScri.remove_Click($buttonGenerateAirWatchScri_Click)
			$buttonGenerateAirWatchScri.remove_MouseClick($buttonGenerateAirWatchScri_MouseClick)
			$formAirWatchAutoEnrollme.remove_Load($Form_StateCorrection_Load)
			$formAirWatchAutoEnrollme.remove_FormClosed($Form_Cleanup_FormClosed)
		}
		catch { Out-Null <# Prevent PSScriptAnalyzer warning #> }
	}
	#endregion Generated Events

	#----------------------------------------------
	#region Generated Form Code
	#----------------------------------------------
	$formAirWatchAutoEnrollme.SuspendLayout()
	$panel1.SuspendLayout()
	$panel2.SuspendLayout()
	#
	# formAirWatchAutoEnrollme
	#
	$formAirWatchAutoEnrollme.Controls.Add($panel1)
	$formAirWatchAutoEnrollme.AutoScaleDimensions = '6, 13'
	$formAirWatchAutoEnrollme.AutoScaleMode = 'Font'
	$formAirWatchAutoEnrollme.BackColor = 'ActiveCaptionText'
	$formAirWatchAutoEnrollme.ClientSize = '891, 409'
	$formAirWatchAutoEnrollme.Name = 'formAirWatchAutoEnrollme'
	$formAirWatchAutoEnrollme.Text = 'AirWatch Auto-Enrollment'
	#
	# panel1
	#
	$panel1.Controls.Add($buttonGenerateAirWatchScri)
	$panel1.Controls.Add($labelPassword)
	$panel1.Controls.Add($labelUsername)
	$panel1.Controls.Add($labelGroupLocationName)
	$panel1.Controls.Add($labelServer)
	$panel1.Controls.Add($panel2)
	$panel1.Controls.Add($passwordtbox)
	$panel1.Controls.Add($Servertbox)
	$panel1.Controls.Add($usernametbox)
	$panel1.Controls.Add($lgnametbox)
	$panel1.BackColor = 'ButtonHighlight'
	$panel1.Location = '0, 27'
	$panel1.Name = 'panel1'
	$panel1.Size = '895, 359'
	$panel1.TabIndex = 0
	#
	# buttonGenerateAirWatchScri
	#
	$buttonGenerateAirWatchScri.BackColor = 'DeepSkyBlue'
	$buttonGenerateAirWatchScri.Font = 'Segoe UI, 8.25pt'
	$buttonGenerateAirWatchScri.Location = '762, 307'
	$buttonGenerateAirWatchScri.Name = 'buttonGenerateAirWatchScri'
	$buttonGenerateAirWatchScri.Size = '108, 39'
	$buttonGenerateAirWatchScri.TabIndex = 38
	$buttonGenerateAirWatchScri.Text = 'Generate AirWatch Script'
	$buttonGenerateAirWatchScri.UseVisualStyleBackColor = $False
	$buttonGenerateAirWatchScri.add_Click($buttonGenerateAirWatchScri_Click)
	$buttonGenerateAirWatchScri.add_MouseClick($buttonGenerateAirWatchScri_MouseClick)
	#
	# labelPassword
	#
	$labelPassword.BackColor = '123, 217, 87'
	$labelPassword.BorderStyle = 'Fixed3D'
	$labelPassword.Font = 'Segoe UI, 9pt'
	$labelPassword.Location = '502, 213'
	$labelPassword.Name = 'labelPassword'
	$labelPassword.Size = '83, 21'
	$labelPassword.TabIndex = 37
	$labelPassword.Text = 'Password'
	#
	# labelUsername
	#
	$labelUsername.BackColor = '123, 217, 87'
	$labelUsername.BorderStyle = 'Fixed3D'
	$labelUsername.Font = 'Segoe UI, 9pt'
	$labelUsername.Location = '73, 213'
	$labelUsername.Name = 'labelUsername'
	$labelUsername.Size = '83, 21'
	$labelUsername.TabIndex = 36
	$labelUsername.Text = 'Username'
	#
	# labelGroupLocationName
	#
	$labelGroupLocationName.BackColor = '123, 217, 87'
	$labelGroupLocationName.BorderStyle = 'Fixed3D'
	$labelGroupLocationName.Font = 'Segoe UI, 9pt'
	$labelGroupLocationName.Location = '502, 110'
	$labelGroupLocationName.Name = 'labelGroupLocationName'
	$labelGroupLocationName.Size = '142, 21'
	$labelGroupLocationName.TabIndex = 35
	$labelGroupLocationName.Text = 'Group Location name'
	#
	# labelServer
	#
	$labelServer.BackColor = '123, 217, 87'
	$labelServer.BorderStyle = 'Fixed3D'
	$labelServer.Font = 'Segoe UI, 9pt'
	$labelServer.Location = '79, 110'
	$labelServer.Name = 'labelServer'
	$labelServer.Size = '83, 21'
	$labelServer.TabIndex = 34
	$labelServer.Text = 'Server'
	#
	# panel2
	#
	$panel2.Controls.Add($picturebox1)
	$panel2.Controls.Add($labelAirWatchAutoEnrollme)
	$panel2.BackColor = 'Gray'
	$panel2.Location = '0, 17'
	$panel2.Name = 'panel2'
	$panel2.Size = '892, 61'
	$panel2.TabIndex = 8
	#
	# picturebox1
	#
	#region Binary Data
	$picturebox1.ErrorImage = [System.Convert]::FromBase64String('
iVBORw0KGgoAAAANSUhEUgAAAM0AAAAhCAIAAAD1WLjHAAAABGdBTUEAALGPC/xhBQAAAAlwSFlz
AAAOvwAADr8BOAVTJAAACSlJREFUeF7t2o+PVcUVB/D+c1Vbwf4SUX6oIGCrtqYWxSKwLSxYU6qx
sbHBCKZKQQ2mtMZiY0PEIKSmpgaRkFAhBAgJaCQEAglh++F9707Gdx/L7qKPmN5vXjYzZ86dM3PO
d86Ze+FbIx06fP3oeNZhGOh41mEY6HjWYRjoeNZhGOh41mEY6HjWYRjoeNZhGOh41mEY6HjWYRjo
eDZs/OTHD6xcsarpfHMwe/adu3fvvveeBU1/iuh4NmwcOnRobGwM25r+0MH08uVPNJ1JY/1v11u2
v01/iuh4Nmw88/Qz77zzzxm3zmz6QweiX7x4selMGuHZ88//selPER3P/u+QhNp0Jo2OZx2mhm8M
z1wJP/nkwPHjxx/5+SONqMJ9Cxe99dbfT548ef78+Q/+9YEuIc0P//2hdE24b9/H69auI5w/7+63
3/7HF1+csQGzvfynl1NNHnrwp2/+7c3v3fb9K9NVWLL4/je2vdGWL1v2eKlEDL3+2us7d+786D8f
Eb606SVWohaw+NRvntL4zi3f9aClKmQZMvNzz/3BU5bKUH1bX7r00dWr10zmUjXnrrmCwYoFuDhb
TN9liPXtf9meNk0rTJtP9u7dmyF/2xG1YPsaKGcuLp11+yzb0eV5s9lFNhtwLLkocLjl5VdPyHtM
Hzx4UPg8vnnzn02YoXI/Y84j0RHKEjXwOC/NmTM33RrT4dmLL25kEk6dOsVqI+2Blz//7POMBohl
6ZcuXWr64xDgs2fPNp1xCLAJeUqbj5pJx2FX5Dbf9MdBbv4f/uBHIkpBmwsg83NrYZLlkXCu96Yc
axAVQySHDx/WxXgT5llDnGhJv1v/NNJc8/pMOceGEyyguAI/iqNYJ0mbLWqGdu3aFU2myTmW30r8
AqeCwtXkCK3t/GtbQ88BJ6/MODZGGLqsWT1KmFhEAZwrQ9bAsRk6evSoRxjSNtWvRn5NITzjSUs1
hGd04iX6Uk90rH/xoiXafZgOzxg2e5BFFHBoMzBd2Mmi+xafPn36wIEDM2fc1sw7MvLgAw+dO3eO
wr59+0rMIPJ3392ljWqOLzJlCDBDsLkvaVVu683wMZIRis3DP3uYXCajxqc1k/idMqrd9O2bRcjv
mjwDanXaQ1+HxzwbNrwQSXhmqdqJdAxJ4VkMbN2ylUTY0g0cPMKryZN95V20K/5hxfqNhkzBwLop
rRIaKl8uTCIWKMUzuuGZNu8VD5tfgiSXNXRH14yuHV23aNHijNaYDs+sgHfMDpzYSHtRzIEA22M7
bUB5QUr1bES9xGMnGCDhNaJxj0ge2vQzM8jVJNlVHcjI6+rQB4GnkOwYnrEryYlHFGDLlq2XL1/u
ix/s2LHjzJmGfKWCTBUeFC0eS7ePZ4YsxiIzGtggnZocfO4YqGX+tuXyYtNvgUKIFYvQ5pkQWIPF
9GVKkKhUW43wjK0+P1CQ1ewi3WKlD9N8D0h0g6QKkB4iEUgRzcqCwgPUaURjYzJwhLZnoREKA0lS
Zl06HSPVxGkjr0snOR+1L20Fc+fMu3Dh4vu739fmhZ6RsVde2ZzRgHWFoOlUkGAoyy5Nf7rYs2fP
hQsXZt9xpbjUPEvIkwz6YMiqSuBTHLmRclvevkvUePXV1+g8uvSxdNs8S/rs43ofEk1Jt+lXSO6o
y0gb0+TZgnsXHjlyxOywbds2knlz53/6308jkQZIap6VDFQiDa6QEUI2D+EZPzoliJXR5KFcQWiW
3BB5fb4RVM5z06ID7hApK5k2+lDzMtxFekWn7yeTGZJcG9VJwE5RIddkkMgtL7tjnUJfPtOu03ZB
LsHlWmLOHKcQq5brlmInu9ivsxfr8px9xaLtRKfNs/d2vUeycMHCpj8IiWb90lCQ0pzdXQ3T5Bnk
EIDjZf81q3LPqCVlESXSUPMsHocQArZv/6vuqpVX2ps2btL+5ePLtTf2ArDiiRVF/uS6J68ojVdb
fjQz60IVpxNm2rD82LFj0Q8EgHACTJ5n2bITwq5XV1GRaTye+3KbZwn53fPv6T39JeSVJUcoxTHp
P+1aXjIxt+MiyDpMP/vs7/nBU3kdmYBnDoMS1HSugmvyrL7MtDF9njk6tsQA8Kndpl2Icp08S/hT
OrmmXEEyQ5FzNHdrx5w997S+hDJtnsW8yAN1n1BiMDrwl/mvCcwQLets3+TqE1/zzK5RsKcyADRT
Its5rJaX2JuNfMni+9Mt4GdqE/DMWxTJwPfEghvGM4gBEOw0oLjjOnkG6ma5k5XvTFDf1fLBCRxx
3XJZLJBry7TJZ7WJwIFRYZvOdJEXDkm06VeQVAy1eSbkE/DMSxJN/izEirzQjhyz800h3vC+H50a
uTdPwLOUJvmv6Q/CjeSZo8NADRejZuyr4Fn2n3fMcgUBuy3ycrkJz9q7TbQm5lleeMsJKUjOmGQ+
87hJ6k0FeJBzOFWe0XEAUKcUyiDlMvLyvh+etUu8Y6YsGio8S+WpD6SF4bGVtO/y1MRR40byDLxp
s1GQNQUDeZZrR1CHRLmJsCbBsseWRYhSjaiH8i1t//79M2c0pzzmaOZ8B17QEuOJeSYYKWFI2Yh6
hTsRaleigWBXtFyGymcw4H1xJTfPVHkGuXFC36e7XP+h/qBjC9IbupeDwdscEuuFZ6GFvzWr3HwI
Ld7jSZxWiFWInhXeYJ65mythzIC391m339EMiNMvlkZ+4sSJO2ffFeHNN92CHJGPjq6NEHLrh76P
CEny7e3ldt/3Pl++EiuCIsTvHCfh8X64hQpG629+BQ5ubHFrYYZ2/j1nklA62fIg02plJtyw4YVE
IjzLV4Do4zHNtAciOdJR6cupKZ1I4IQ0ol55seDos84JFJjuu5/ZKTlJUE5dvsqSGC0xtYVkPoTW
rfNIQUhfUslAXC/PYOWKVXblYl6XtgA/xLvvv/XZMKF7TLlwgFV6S/LrS91yA2HtzSDyZIUaAqPE
8B3/clxm4+iSqNi92n8zFEt3FF7zuEksvm8xkwEncIUsItOzlY+caGHaKOB9+bcBqx0YuRoO3sAv
W85Y+wxwiIss0xZAIVkQUZzA+u3EInkP410YCv+A3NpE05BdsFv4bWYrqWtFAX5P/AEPvgKedehw
TXQ86zAMdDzrMAx0POswDHQ86/D1Y2Tkf/FkDwaMN+aaAAAAAElFTkSuQmCC')
	#endregion
	$picturebox1.ImageLocation = 'System.Drawing.Bitmap'
	#region Binary Data
	$picturebox1.InitialImage = [System.Convert]::FromBase64String('
iVBORw0KGgoAAAANSUhEUgAAAM0AAAAhCAIAAAD1WLjHAAAABGdBTUEAALGPC/xhBQAAAAlwSFlz
AAAOvwAADr8BOAVTJAAACSlJREFUeF7t2o+PVcUVB/D+c1Vbwf4SUX6oIGCrtqYWxSKwLSxYU6qx
sbHBCKZKQQ2mtMZiY0PEIKSmpgaRkFAhBAgJaCQEAglh++F9707Gdx/L7qKPmN5vXjYzZ86dM3PO
d86Ze+FbIx06fP3oeNZhGOh41mEY6HjWYRjoeNZhGOh41mEY6HjWYRjoeNZhGOh41mEY6HjWYRjo
eDZs/OTHD6xcsarpfHMwe/adu3fvvveeBU1/iuh4NmwcOnRobGwM25r+0MH08uVPNJ1JY/1v11u2
v01/iuh4Nmw88/Qz77zzzxm3zmz6QweiX7x4selMGuHZ88//selPER3P/u+QhNp0Jo2OZx2mhm8M
z1wJP/nkwPHjxx/5+SONqMJ9Cxe99dbfT548ef78+Q/+9YEuIc0P//2hdE24b9/H69auI5w/7+63
3/7HF1+csQGzvfynl1NNHnrwp2/+7c3v3fb9K9NVWLL4/je2vdGWL1v2eKlEDL3+2us7d+786D8f
Eb606SVWohaw+NRvntL4zi3f9aClKmQZMvNzz/3BU5bKUH1bX7r00dWr10zmUjXnrrmCwYoFuDhb
TN9liPXtf9meNk0rTJtP9u7dmyF/2xG1YPsaKGcuLp11+yzb0eV5s9lFNhtwLLkocLjl5VdPyHtM
Hzx4UPg8vnnzn02YoXI/Y84j0RHKEjXwOC/NmTM33RrT4dmLL25kEk6dOsVqI+2Blz//7POMBohl
6ZcuXWr64xDgs2fPNp1xCLAJeUqbj5pJx2FX5Dbf9MdBbv4f/uBHIkpBmwsg83NrYZLlkXCu96Yc
axAVQySHDx/WxXgT5llDnGhJv1v/NNJc8/pMOceGEyyguAI/iqNYJ0mbLWqGdu3aFU2myTmW30r8
AqeCwtXkCK3t/GtbQ88BJ6/MODZGGLqsWT1KmFhEAZwrQ9bAsRk6evSoRxjSNtWvRn5NITzjSUs1
hGd04iX6Uk90rH/xoiXafZgOzxg2e5BFFHBoMzBd2Mmi+xafPn36wIEDM2fc1sw7MvLgAw+dO3eO
wr59+0rMIPJ3392ljWqOLzJlCDBDsLkvaVVu683wMZIRis3DP3uYXCajxqc1k/idMqrd9O2bRcjv
mjwDanXaQ1+HxzwbNrwQSXhmqdqJdAxJ4VkMbN2ylUTY0g0cPMKryZN95V20K/5hxfqNhkzBwLop
rRIaKl8uTCIWKMUzuuGZNu8VD5tfgiSXNXRH14yuHV23aNHijNaYDs+sgHfMDpzYSHtRzIEA22M7
bUB5QUr1bES9xGMnGCDhNaJxj0ge2vQzM8jVJNlVHcjI6+rQB4GnkOwYnrEryYlHFGDLlq2XL1/u
ix/s2LHjzJmGfKWCTBUeFC0eS7ePZ4YsxiIzGtggnZocfO4YqGX+tuXyYtNvgUKIFYvQ5pkQWIPF
9GVKkKhUW43wjK0+P1CQ1ewi3WKlD9N8D0h0g6QKkB4iEUgRzcqCwgPUaURjYzJwhLZnoREKA0lS
Zl06HSPVxGkjr0snOR+1L20Fc+fMu3Dh4vu739fmhZ6RsVde2ZzRgHWFoOlUkGAoyy5Nf7rYs2fP
hQsXZt9xpbjUPEvIkwz6YMiqSuBTHLmRclvevkvUePXV1+g8uvSxdNs8S/rs43ofEk1Jt+lXSO6o
y0gb0+TZgnsXHjlyxOywbds2knlz53/6308jkQZIap6VDFQiDa6QEUI2D+EZPzoliJXR5KFcQWiW
3BB5fb4RVM5z06ID7hApK5k2+lDzMtxFekWn7yeTGZJcG9VJwE5RIddkkMgtL7tjnUJfPtOu03ZB
LsHlWmLOHKcQq5brlmInu9ivsxfr8px9xaLtRKfNs/d2vUeycMHCpj8IiWb90lCQ0pzdXQ3T5Bnk
EIDjZf81q3LPqCVlESXSUPMsHocQArZv/6vuqpVX2ps2btL+5ePLtTf2ArDiiRVF/uS6J68ojVdb
fjQz60IVpxNm2rD82LFj0Q8EgHACTJ5n2bITwq5XV1GRaTye+3KbZwn53fPv6T39JeSVJUcoxTHp
P+1aXjIxt+MiyDpMP/vs7/nBU3kdmYBnDoMS1HSugmvyrL7MtDF9njk6tsQA8Kndpl2Icp08S/hT
OrmmXEEyQ5FzNHdrx5w997S+hDJtnsW8yAN1n1BiMDrwl/mvCcwQLets3+TqE1/zzK5RsKcyADRT
Its5rJaX2JuNfMni+9Mt4GdqE/DMWxTJwPfEghvGM4gBEOw0oLjjOnkG6ma5k5XvTFDf1fLBCRxx
3XJZLJBry7TJZ7WJwIFRYZvOdJEXDkm06VeQVAy1eSbkE/DMSxJN/izEirzQjhyz800h3vC+H50a
uTdPwLOUJvmv6Q/CjeSZo8NADRejZuyr4Fn2n3fMcgUBuy3ycrkJz9q7TbQm5lleeMsJKUjOmGQ+
87hJ6k0FeJBzOFWe0XEAUKcUyiDlMvLyvh+etUu8Y6YsGio8S+WpD6SF4bGVtO/y1MRR40byDLxp
s1GQNQUDeZZrR1CHRLmJsCbBsseWRYhSjaiH8i1t//79M2c0pzzmaOZ8B17QEuOJeSYYKWFI2Yh6
hTsRaleigWBXtFyGymcw4H1xJTfPVHkGuXFC36e7XP+h/qBjC9IbupeDwdscEuuFZ6GFvzWr3HwI
Ld7jSZxWiFWInhXeYJ65mythzIC391m339EMiNMvlkZ+4sSJO2ffFeHNN92CHJGPjq6NEHLrh76P
CEny7e3ldt/3Pl++EiuCIsTvHCfh8X64hQpG629+BQ5ubHFrYYZ2/j1nklA62fIg02plJtyw4YVE
IjzLV4Do4zHNtAciOdJR6cupKZ1I4IQ0ol55seDos84JFJjuu5/ZKTlJUE5dvsqSGC0xtYVkPoTW
rfNIQUhfUslAXC/PYOWKVXblYl6XtgA/xLvvv/XZMKF7TLlwgFV6S/LrS91yA2HtzSDyZIUaAqPE
8B3/clxm4+iSqNi92n8zFEt3FF7zuEksvm8xkwEncIUsItOzlY+caGHaKOB9+bcBqx0YuRoO3sAv
W85Y+wxwiIss0xZAIVkQUZzA+u3EInkP410YCv+A3NpE05BdsFv4bWYrqWtFAX5P/AEPvgKedehw
TXQ86zAMdDzrMAx0POswDHQ86/D1Y2Tkf/FkDwaMN+aaAAAAAElFTkSuQmCC')
	#endregion
	$picturebox1.Location = '3, 12'
	$picturebox1.Name = 'picturebox1'
	$picturebox1.Size = '192, 30'
	$picturebox1.TabIndex = 34
	$picturebox1.TabStop = $False
	#
	# labelAirWatchAutoEnrollme
	#
	$labelAirWatchAutoEnrollme.AutoSize = $True
	$labelAirWatchAutoEnrollme.Font = 'Segoe UI, 12pt, style=Bold'
	$labelAirWatchAutoEnrollme.ForeColor = 'White'
	$labelAirWatchAutoEnrollme.Location = '633, 31'
	$labelAirWatchAutoEnrollme.Name = 'labelAirWatchAutoEnrollme'
	$labelAirWatchAutoEnrollme.Size = '212, 21'
	$labelAirWatchAutoEnrollme.TabIndex = 33
	$labelAirWatchAutoEnrollme.Text = 'AirWatch Auto-Enrollment'
	#
	# passwordtbox
	#
	$passwordtbox.Location = '502, 252'
	$passwordtbox.Name = 'passwordtbox'
	$passwordtbox.Size = '119, 29'
	$passwordtbox.TabIndex = 7
	$passwordtbox.Text = ''
	#
	# Servertbox
	#
	$Servertbox.Location = '79, 149'
	$Servertbox.Name = 'Servertbox'
	$Servertbox.Size = '246, 29'
	$Servertbox.TabIndex = 4
	$Servertbox.Text = ''
	#
	# usernametbox
	#
	$usernametbox.Location = '73, 252'
	$usernametbox.Name = 'usernametbox'
	$usernametbox.Size = '252, 29'
	$usernametbox.TabIndex = 6
	$usernametbox.Text = ''
	#
	# lgnametbox
	#
	$lgnametbox.Location = '502, 149'
	$lgnametbox.Name = 'lgnametbox'
	$lgnametbox.Size = '119, 29'
	$lgnametbox.TabIndex = 5
	$lgnametbox.Text = ''
	$panel2.ResumeLayout()
	$panel1.ResumeLayout()
	$formAirWatchAutoEnrollme.ResumeLayout()
	#endregion Generated Form Code

	#----------------------------------------------

	#Save the initial state of the form
	$InitialFormWindowState = $formAirWatchAutoEnrollme.WindowState
	#Init the OnLoad event to correct the initial state of the form
	$formAirWatchAutoEnrollme.add_Load($Form_StateCorrection_Load)
	#Clean up the control events
	$formAirWatchAutoEnrollme.add_FormClosed($Form_Cleanup_FormClosed)
	#Show the Form
	return $formAirWatchAutoEnrollme.ShowDialog()

} #End Function

#Call the form
Show-AirwatchAutoenrollment_psf | Out-Null
