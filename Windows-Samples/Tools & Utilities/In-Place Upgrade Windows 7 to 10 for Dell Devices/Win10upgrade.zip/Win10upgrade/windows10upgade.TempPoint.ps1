﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2016 v5.3.131
	 Created on:   	1/25/2017 11:13 AM
	 Created by:   	jhandy
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>


### Confirm if the installation  folder exists
$installfile = "C:\DeplymentShare\Win10upgrade\Install.cmd"
if (Test-Path $installfile)
	{
	
	### Confirming and upgrading to Windows 10 Enterprise 64-bit if applicable
	$computer = "."
	$winversion = Get-WMIObject Win32_OperatingSystem -ComputerName $computer | select-object Description, Caption, OSArchitecture, ServicePackMajorVersion
	
	If ($winversion -match "64-bit")
	{
		If ($winversion -notmatch "Windows 10")
		{
			& "C:\DeplymentShare\Win10upgrade\Install.cmd"
		}
		### Confirming Parition Style, and bois type
		
		$partitionstyle = gwmi -query "Select * from Win32_DiskPartition WHERE Index = 0" | Select-Object DiskIndex, @{ Name = "GPT"; Expression = { $_.Type.StartsWith("GPT") } }
		$OSBuild = [System.Environment]::OSVersion.Version
		
		If ($partitionstyle -notmatch "True")
		{
			
			cd c:\DeplymentShare\Win10upgrade\MBRGPT
			
			
         	Start-Job -Name Job1 -ScriptBlock { & "C:\DeplymentShare\Win10upgrade\vcredist_x86_2013.bat" }
			Wait-Job -Name Job1
            
            Start-Job -Name Job2 -ScriptBlock { & "C:\DeplymentShare\Win10upgrade\vcredist_x86_2015.bat" }
			Wait-Job -Name Job2
            

			
			& "C:\DeplymentShare\Win10upgrade\MBR2GPT.cmd"
			& "C:\DeplymentShare\Win10upgrade\boistouefi.cmd"
			& "C:\DeplymentShare\Win10upgrade\DisableUAC.ps1"
			
			
			
			Restart-Computer -Force
			
		}
		
		$DriveLetter = (Get-Volume -FileSystemLabel "SYSTEM RESERVED").DriveLetter
		
		IF ($DriveLetter -ne $null)
		{
			$AccPath = ($DriveLetter + ":")
			$PartNo = (Get-Partition -DriveLetter $DriveLetter).PartitionNumber
			$DiskNo = (Get-Partition -DriveLetter $DriveLetter).DiskNumber
			Remove-PartitionAccessPath -DiskNumber $DiskNo -PartitionNumber $PartNo -AccessPath $AccPath
		}
		
		$AirWatchInstalled = Test-Path "C:\Program Files (x86)\AirWatch\AgentUI\ar"
		
		IF ($AirWatchInstalled -eq $false)
		{
                  
            Start-Sleep -s 60

			C:\DeplymentShare\Win10upgrade\AirwatchAgent.cmd -en ASCII
		}
	}
	
	
	
}




