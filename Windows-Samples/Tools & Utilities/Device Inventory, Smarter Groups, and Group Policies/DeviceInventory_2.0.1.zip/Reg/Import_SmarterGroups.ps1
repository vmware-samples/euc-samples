﻿<#================Module Header====================#>

$current_path = $PSScriptRoot;
$useDebugConfig = $false;
if($PSScriptRoot -eq ""){
    $current_path = "C:\Temp\Reg";
}



$InstallPath = "HKLM:\Software\AIRWATCH\ProductProvisioning";
$shared_path = "C:\Temp\Shared"
If(Test-Path $InstallPath){
    $getShared_path = ((Get-ItemProperty -Path $InstallPath).PSObject.Properties | where Name -eq "SharedPath") | Measure;
    If($getShared_path.Count -gt 0){
        $shared_path = Get-ItemPropertyValue -Path $InstallPath -Name "SharedPath";       
    }
} Else { 
    return;
}

if(Test-Path "$shared_path\api-debug.config"){
    $Debug = 1;
}

Try{
    Unblock-File "$shared_path\AirWatchAPI.psm1"
    $module = Import-Module "$shared_path\AirWatchAPI.psm1" -ErrorAction Stop -PassThru -Force;
    Unblock-File "$current_path\SmarterGroupsLogic.psm1"
    $smartergroups_module = Import-Module "$current_path\SmarterGroupsLogic.psm1" -ErrorAction Stop -PassThru -Force;
    Unblock-File "$shared_path\Update-Registry.psm1"
    $registry_module = Import-Module "$shared_path\Update-Registry.psm1" -ErrorAction Stop -PassThru -Force;
} Catch{    
    $ErrorMessage = $_.Exception.Message;
    Add-Content $logLocation "An error has occurrred.  Error: $ErrorMessage"
}

$log_path = Get-ItemPropertyValueSafe -Path $InstallPath -Name "LogPath" -DefaultVal "C:\Temp\Logs";
$logLocation = "$log_path\SmarterGroups.log"; 

<#================Module Body====================#>
 
#Get the serial number of the machine
$serialSearch = wmic bios get serialnumber
$serialnumber = $serialSearch[2]
$serialnumber = $serialnumber.Trim();

#Set API content types
$content_type = "application/json;version=1";
$content_type_v2 = "application/json;version=2";

$api_settings_obj = Get-AWAPIConfiguration;

$Server = $api_settings_obj.ApiConfig.Server;
$API_Key = $api_settings_obj.ApiConfig.ApiKey
$Auth = $api_settings_obj.ApiConfig.ApiAuth;
$OrganizationGroupId = $api_settings_obj.ApiConfig.OrganizationGroupId;
$deviceid = $api_settings_obj.ApiConfig.DeviceId;

#Static api paths

#$serialEncoded = [System.Web.HttpUtility]::UrlEncode($serialnumber);
#$deviceSearchEndpoint = "$server/api/mdm/devices?searchBy=Serialnumber&id=$serialEncoded";
$tags_endpoint = "$server/api/mdm/tags/search?organizationgroupid=$OrganizationGroupId&name=";
$device_endpoint = "$server/api/mdm/devices/$deviceid/";
$add_tag_endpoint = "$server/api/mdm/tags/addtag";
$addDeviceEndpoint = "$server/api/mdm/tags/{tagid}/adddevices";
$removeDeviceEndpoint = "$server/api/mdm/tags/{tagid}/removedevices";
$change_og_endpoint = "$server/api/mdm/devices/$deviceid/commands/changeorganizationgroup/";
$og_search_endpoint = "$server/api/system/groups/search";

$Headers = @{"Authorization"=$Auth;"aw-tenant-code"=$API_Key;"accept"=$content_type;"content-type"=$content_type};
$Headers_alt = @{"Authorization"=$Auth;"aw-tenant-code"=$API_Key;"accept"=$content_type_v2;"content-type"=$content_type_v2};

$getApplicationsEndpoint = "$server/api/mdm/devices/$deviceid/apps"
$getProfilesEndpoint = "$server/api/mdm/devices/$deviceid/profiles"


$bulk_items = @"
{
  "BulkValues": {
    "Value": [
      $deviceId
    ]
  }
}
"@

$tag_format = @"
{
  "TagAvatar":"{tagname}",
  "TagName": "{tagname}",
  "TagType": 1,
  "LocationGroupId": $OrganizationGroupId
}
"@


$ObjectCache = @{};
$SmarterGroupsErrors = @();
$SmarterGroupsConfigs = @{};
    
$profiles_request = Invoke-AWApiCommand -Endpoint $getProfilesEndpoint -Header $Headers
if($profiles_request.DeviceProfiles){
    if(!$ObjectCache.ContainsKey("Profiles")){     
        $ObjectCache.Add("Profiles", $profiles_request.DeviceProfiles);
    }
    $Profiles = New-Object -TypeName PSCustomObject -Property @{"Profiles"=@()};
    ForEach($ProfileObj in $profiles_request.DeviceProfiles){
        $ProfileCacheObj = New-Object -TypeName PSCustomObject -Property @{"Id"= $ProfileObj.Id.Value;
            "Name"=$ProfileObj.Name;"Status"=$ProfileObj.Status };
        $Profiles.Profiles += $ProfileCacheObj;
    }
    $ProfileCache = ConvertTo-Json $Profiles -Depth 10;
    $EncryptedProfileCache = ConvertTo-EncryptedFile -FileContents $ProfileCache;

    Set-Content -Path "$current_path\Profiles\InstallList.db" -Value $EncryptedProfileCache;

    $InventoryFiles = Get-ChildItem -Path "$current_path\Profiles\"
    foreach($InventoryFile in $InventoryFiles){
        If($InventoryFile -match "([0-9]{1,10})\.(map|settings|ps1x)"){
                $ValidProfiles = @(3,6);
                $profile_id_test = $Matches[1];
                If((($ObjectCache.Profiles | where {$_.Id.Value -eq $profile_id_test -and $_.Status -in $ValidProfiles}) | Measure).Count -lt 1){
                $inventory_filename = $InventoryFile.Name;
                If($Matches[2] -eq "ps1x"){
                    Invoke-UninstallPowershellFile -FileName $InventoryFile.FullName;
                } Else {
                    Remove-Item "$current_path\Profiles\$inventory_filename";
                }
             } 
        }
    }
}

$DynamicGroupsFiles = Get-ChildItem -Path "$current_path\Profiles\" -Filter "*.map"
Write-Log2 -Path $logLocation -Message ("Number of files found: " + ($DynamicGroupsFiles | measure).Count)

$SGAuditReg = @{};
$SGAuditAlais = @{};
ForEach($DynamicGroupsFile in $DynamicGroupsFiles){
    $ProfileId = $DynamicGroupsFile.BaseName;
    $ProfileName = $ProfileId;
    If($ProfileId -match "[1-9]{1}[0-9]{0,9}"){
       
        $ProfileNameSearch = $ObjectCache["Profiles"] | where {$_.Id.Value -eq $ProfileId};
        If($ProfileNameSearch){
            $ProfileName = $ProfileNameSearch.Name;
        }
    }
    $SGAuditReg.Add("$ProfileId","");
    $SGAuditAlais.Add("SmarterGroups.$ProfileName","$ProfileId");
    Try{
        $DynamicGroups = [IO.File]::ReadAllText($DynamicGroupsFile.FullName);
        if(!($DynamicGroups.Contains("TagMaps"))){
            Write-Log2 -Path $logLocation -Message ("Getting encrypted file: " + $DynamicGroupsFile.FullName)
            $DynamicGroups = ConvertFrom-EncryptedFile -FileContents $DynamicGroups
        }
        If($DynamicGroups -notlike "Error: *"){
            $DynamicGroupsObj = ConvertFrom-Json -InputObject $DynamicGroups
            $SmarterGroupsConfigs.Add($DynamicGroupsFile.BaseName, $DynamicGroupsObj);
        } Else{
            $SGAuditReg[$ProfileId] = $DynamicGroups;
        }
    } Catch{
        $ErrorMessage = $_.Exception.Message;
        $SmarterGroupsErrors += $DynamicGroupsFile;
        Write-Log2 -Path $logLocation -Message ("Error converting JSON: " + $ErrorMessage)
        $SGAuditReg[$ProfileId] = "Error converting JSON: " + $ErrorMessage
    }
}


ForEach($SmarterGroupsId in $SmarterGroupsConfigs.Keys){
    $DG_Object = $SmarterGroupsConfigs[$SmarterGroupsId];

    $CommitTxt = "UPDATES COMMITED";
    $CommitUpdates = 1;
    $Debug = 0;
    If($DG_Object.CommitUpdates){
        $CommitUpdates = $DG_Object.CommitUpdates;
        $CommitTxt = "UPDATES NOT COMMITTED";
    }
    If($DG_Object.Debug){
        $Debug = $DG_Object.Debug;
    }

    $ResultProp = @{"AddedTags" = @();"RemovedTags" = @();"OGChanges" = @();};
    $ResultObj = New-Object -TypeName PSCustomObject -Property $ResultProp;
    If($DG_Object.TagMaps){
        $results = @{"Serial"=$serialnumber;"Tags"=@()}; 
        ForEach($Tag in $DG_Object.TagMaps){
          
            $tag_id = "";
            $ogid = "";
            #Get tagID       
            If($Tag.TagName){
                $name = $Tag.TagName;
                $tags_json = Invoke-AWApiCommand -Endpoint ("$tags_endpoint" + $Tag.TagName) -Header $Headers
                If($tags_json){
                    If($tags_json.Tags.Count -gt 0){
                        $tag_id = $tags_json.Tags[0].Id.Value;
                    } 
                } 

                If(!$tag_id) {
                    $body = $tag_format.Replace("{tagname}", $Tag.TagName)
                    $add_tag = Invoke-AWApiCommand -Method Post -Endpoint $add_tag_endpoint -Headers $Headers -Data $body; 
                    if($add_tag.Value){
                        $tag_id = $add_tag.Value;
                    }
                }
            } ElseIf ($Tag.NewOrganizationGroup -or $Tag.NewOrganizationGroupID -or $Tag.NewGroupId) {
                If($Tag.NewOrganizationGroupId){
                    $ogid = $Tag.NewOrganizationGroupId;
                } ElseIf ($Tag.NewOrganizationGroup){
                    $OG_Search = Invoke-AWApiCommand -Endpoint ("$og_search_endpoint`?name=" + $Tag.NewOrganizationGroup ) -Headers $Headers_alt;
                    If($OG_Search.OrganizationGroups){
                        $ogid = $OG_Search.OrganizationGroups[0].Id;
                    }
                } ElseIf ($Tag.NewGroupId){
                    $OG_Search = Invoke-AWApiCommand -Endpoint ("$og_search_endpoint`?groupid=" + $Tag.NewGroupId ) -Headers $Headers_alt;
                    If($OG_Search.OrganizationGroups){
                        $ogid = $OG_Search.OrganizationGroups[0].Id;
                    }
                }
            }
        
            If($Tag.Type -eq "PowerShell"){   
                If($Debug){
                    Write-Log2 -Path $logLocation -Message $Tag.PSLogic;
                }

                $PSResult = (Invoke-ExpressionSafe -Command $Tag.PSLogic -Debug $Debug);

                If($Debug){
                    Write-Log2 -Path $logLocation -Message ($PSResult | Format-List | Out-String);
                }
                 
                If ($tag_id){
                    If($PSResult -like "*Error*"){
                        Write-Log2 -Path $logLocation -Message "An error occured: $PSResult";
                    } ElseIf($PSResult -eq $true){ 
                        If($CommitUpdates){
                            $add_tags = Invoke-AWApiCommand -Method Post -Endpoint ($addDeviceEndpoint.Replace("{tagid}",$tag_id)) -Headers $Headers -Data $bulk_items;
                        }
                        $ResultObj.AddedTags += $Tag.TagName                
                    } ElseIf($PSResult -eq $false) {
                        If(!$Tag.Static){
                            If($CommitUpdates){
                                $remove_tags = Invoke-AWApiCommand -Method Post -Endpoint ($removeDeviceEndpoint.Replace("{tagid}",$tag_id)) -Headers $Headers -Data $bulk_items;
                            }
                            $ResultObj.RemovedTags += $Tag.TagName;
                        }
                    } Else{
                        Write-Log2 -Path $logLocation -Message "An error occured: $PSResult";
                    }
                } ElseIf ($ogid -and $PSResult){
                    If($CommitUpdates){
                        $ogmove = Invoke-AWApiCommand -Method Put -Endpoint ($change_og_endpoint + "$ogid") -Headers $Headers
                    }
                    $ResultObj.OGChanged += $ogid;
                }
 
                  
            } Elseif($Tag.Type -eq "AirWatch") {
                If($Tag.Triggers | where "Type" -eq "Application"){
                    If(!$ObjectCache.ContainsKey("Application")){
                        $application_request = Invoke-AwApiCommand -Endpoint $getApplicationsEndpoint -Headers $Headers;
                        if($application_request.DeviceApps){
                            $ObjectCache['Application'] = $application_request.DeviceApps;
                        }
                    }
                }
                If($Tag.Triggers | where "Type" -eq "Profile"){
                    If(!$ObjectCache.ContainsKey("Profile")){
                        $profiles_request = Invoke-AwApiCommand -Endpoint $getProfilesEndpoint -Headers $Headers;
                        if($profiles_request.DeviceProfiles){
                            $ObjectCache['Profile'] = $profiles_request.DeviceProfiles;
                        }
                    }
                }
                If($Tag.Triggers | where "Type" -eq "Device"){
                    If(!$ObjectCache.ContainsKey("Device")){
                        $device_request = Invoke-AwApiCommand -Endpoint $device_endpoint -Headers $Headers;
                        if($device_request){
                            $ObjectCache['Device'] = $device_request;
                        }
                    }
                }
                $results = Get-AWItemStatus -Cache $ObjectCache -Triggers $Tag.Triggers;

                if($tag_id){
                    if($results -ge 0){
                        If($CommitUpdates){
                            $add_tags = Invoke-AWApiCommand -Method Post -Endpoint ($addDeviceEndpoint.Replace("{tagid}",$tag_id)) -Headers $Headers -Data $bulk_items;
                        }
                       $ResultObj.AddedTags += $Tag.TagName;
                    } else {
                        if(!$Tag.Static){
                            If($CommitUpdates){
                                $remove_tags = Invoke-AWApiCommand -Method Post -Endpoint ($removeDeviceEndpoint.Replace("{tagid}",$tag_id)) -Headers $Headers -Data $bulk_items;
                            }
                        }
                         $ResultObj.RemovedTags += $Tag.TagName;
                    }
                } Elseif ($ogid){
                    If($CommitUpdates){
                        $ogmove = Invoke-AWApiCommand -Method Put -Endpoint ($change_og_endpoint + "$ogid") -Headers $Headers
                    }
                    $ResultObj.OGChanges += $ogid;
                }
            }
            
        }
        If($Debug){
            Write-Log2 -Path $logLocation -Message "$CommitTxt"
            Write-Log2 -Path $logLocation -Message ($ResultObj | Format-List | Out-String)
        }
        $SGAuditReg[$ProfileId] = "Added= " + $resultObj.AddedTags.Count + ",Removed= " + $resultObj.RemovedTags.Count + ",OGs Changed = " + $resultObj.OGChanges.Count;
    }   
}

$InstallPath = "HKLM:\Software\AirWatch\ProductProvisioning\SmarterGroups"
$timestamp = (date).ToString("MM-dd-yyyy hh.mm.ss"); 
$SGAuditReg.Add("LastScanComplete", $timestamp);
$SGAuditAlais.Add("SmarterGroups.LastScan","LastScanComplete");
Set-RegistryKeyValue -source "SmarterGroups" -key $InstallPath -keyvalues $SGAuditReg -CVFormatted $true;
Add-CustomVariables -xmlPath "SmarterGroups.xml" -keyPath "Software\AirWatch\ProductProvisioning\SmarterGroups" -aliasMap $SGAuditAlais;