﻿<#================Module Header====================#>
$current_path = $PSScriptRoot;
if($PSScriptRoot -eq ""){
    $current_path = "C:\Temp\Reg";
}

cd $current_path;

$InstallPath = "HKLM:\Software\AIRWATCH\ProductProvisioning";
$shared_path = "C:\Temp\Shared"
If(Test-Path $InstallPath){
    $getShared_path = ((Get-ItemProperty -Path $InstallPath).PSObject.Properties | where Name -eq "SharedPath") | Measure;
    If($getShared_path.Count -gt 0){
        $shared_path = Get-ItemPropertyValue -Path $InstallPath -Name "SharedPath";       
    }
} Else { 
    return;
}


Try{
    Unblock-File "$shared_path\AirWatchAPI.psm1"
    $module = Import-Module "$shared_path\AirWatchAPI.psm1" -ErrorAction Stop -PassThru -Force;
} Catch{    
    $ErrorMessage = $_.Exception.Message;
    Write-Log2 -Path $log_path -Message "An error has occured: $ErrorMessage" -Level Error;
}      

$GPPath = "C:\Temp\GroupPolicy";
$getGPPath = Get-ItemPropertyValueSafe -Path $InstallPath -Name "ImportGroupPolicy" -DefaultVal "C:\Temp\GroupPolicy";

$log_path = Get-ItemPropertyValueSafe -Path $InstallPath -Name "LogPath" -DefaultVal "C:\Temp\Logs";
$logLocation = "$log_path\Profiles.log"; 

<#================Module Body====================#>
$raw_profile_files = @();
$raw_profiles = Get-ChildItem -Path "$current_path\Queue" -Filter "*.profile" -Force
if($raw_profiles){
    $raw_profile_files += $raw_profiles;
}
$unattended_profiles = Get-ChildItem -Path "C:\Temp" -Filter "*.profile" -Force
If(!$unattended){
    $raw_profile_files += $unattended_profiles;
}

$Extenions = @{"SmarterGroups"="map";"CustomAttributes"="settings";"GroupPolicy"="txt";"PSProfile"="ps1x"};
$TaskPath = "\AirWatch MDM\";
$TaskList = @{"SmarterGroups"="Install_SmarterGroups";"CustomAttributes"="Install_CustomSettings";"GroupPolicy"="Import_GroupPolicy"};

ForEach($raw_profile in $raw_profile_files){
    $Data = [IO.File]::ReadAllText($raw_profile.FullName);
    $RawName = $raw_profile.BaseName;
    If($RawName -match "([^\-]*)\-([0-9]{1,10})"){
        $TemplateType = $Matches[1];
        $Name = $Matches[2];
        $Extension = $Extenions[$TemplateType];
        If ($TemplateType -eq "CustomAttributes" -or $TemplateType -eq "SmarterGroups"){
                $DecodedData = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($Data));
                $EncryptedData = ConvertTo-EncryptedFile $DecodedData;
                Set-Content -Path "$current_path\Profiles\$Name.$Extension" -Value $EncryptedData -Force;
                Remove-Item -Path $raw_profile.FullName;     
        } ElseIf($TemplateType -eq "GroupPolicy"){
                $DecodedData = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($Data));
                $EncryptedData = ConvertTo-EncryptedFile $DecodedData;
                Set-Content -Path "$GPPath\Queue\$Name.$Extension" -Value $EncryptedData -Force;
                Remove-Item -Path $raw_profile.FullName;
        } ElseIf($TemplateType -eq "PSProfile"){
                $DecodedData = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($Data));
                If($DecodedData -match "(?s)\#START_INSTALL_CMD`r`n(.*)\#END_INSTALL_CMD`r`n\#START_UNINSTALL_CMD`r`n(.*)\#END_UNINSTALL_CMD"){
                    $InstallPS = $Matches[1];
                    $UninstallPS = $Matches[2];
                    Try{
                        $Results = (iex $InstallPS)
                        $EncryptedData = ConvertTo-EncryptedFile $UninstallPS;
                        Set-Content -Path "$current_path\Profiles\$Name.$Extension" -Value $EncryptedData -Force;
                    } Catch{

                    }
                }
                Remove-Item -Path $raw_profile.FullName;
                continue;
        } Else {
            continue;
        }
        Start-ScheduledTask -TaskName $TaskList[$TemplateType] -TaskPath $TaskPath;
    }
}