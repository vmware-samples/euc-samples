﻿<#
    File: Import_CustomSettings.ps1
    Author: cbradley@vmware.com
#>

Param(
    [Parameter(Mandatory=$false)]
    [ValidateSet("Install","Remove","Reconcile")]
    [string]$Action="Install",
    [Parameter(Mandatory=$false)]
    [ValidateSet("All","Registry","CustomVariables")]
    [string]$InstallType="All"
)

#Logging information
$logLocation = "C:\Temp\Logs\DeviceInventory.log";

function Test-ItemProperty{
    Param([string]$Path, [string]$Name)
    return (Get-Item -Path $Path).GetValue($Name) -ne $null;
}

 #Current file information
$source = "Inventory"
$current_version = "2.1.0"

#Get current path
$current_path = $PSScriptRoot;
if($PSScriptRoot -eq ""){
    $current_path = "C:\Temp\Reg";
}

#Import library
$source = $current_path + "\Installed\" + $source + ".keys"

#Set common folder locations 
$InstallPath = "HKLM:\Software\AIRWATCH\ProductProvisioning";
If(Test-Path -Path $InstallPath){
    If(Test-ItemProperty -Path $InstallPath -Name "LogPath"){
        $logLocation = (Get-ItemPropertyValue -Path $InstallPath -Name "LogPath") + "\DeviceInventory.log";        
    }
} 
    
$sharedPath = "C:\Temp\Shared"
If(Test-ItemProperty -Path $InstallPath -Name "SharedPath"){
    $sharedPath = (Get-ItemPropertyValue -Path $InstallPath -Name "SharedPath");       
}

#Import Libraries and Functions
Try{
    Unblock-File "$sharedPath\Update-Registry.psm1"
    $module = Import-Module "$sharedPath\Update-Registry.psm1" -ErrorAction Stop -PassThru -Force;
    Unblock-File "$sharedPath\AirWatchAPI.psm1"
    $apimodule = Import-Module "$sharedPath\AirWatchAPI.psm1" -ErrorAction Stop -PassThru -Force;
    Unblock-File "$current_path\SmarterGroupsLogic.psm1"
    $sglmodule = Import-Module "$current_path\SmarterGroupsLogic.psm1" -ErrorAction Stop -PassThru -Force;
} Catch{    
    $ErrorMessage = $_.Exception.Message;
    Write-Log2 -Path $logLocation -Message "An error has occurrred.  Error: $ErrorMessage"
    return;
}

#Check to see that the AirWatch Agent is installed
$airwatchInstallDir = Get-ItemPropertyValueSafe -Path "HKLM:\Software\AIRWATCH" -Name "INSTALLDIR" -DefaultVal "C:\Program Files (x86)\AirWatch";

Function Apply-CustomVariables{
    

    #Get setup JSON
    $Debug = 1;
    if(!(Test-Path "$current_path\Profiles")){
        New-Item -Path "$current_path\Profiles" -ItemType Directory -Force;
    }

    #Get installed profiles
    $settingsFiles = Get-ChildItem -Path "$current_path\Profiles\" -Name "*.settings"
    $numFiles = ($settingsFiles | measure).Count
    Write-Log2 -Path $logLocation "$numFiles found.  Processing files now."

    $InstalledXML = Get-ChildItem -Path "$airwatchInstallDir\AgentUI\Cache\Profiles" -Filter "*.xml" | where {$_.BaseName -match "[1-9]{1}[0-9]{0,9}"}
    $RemovedFiles = $InstalledXML | where {$_.BaseName -notin 
        ($settingsFiles | Select-Object @{Name='BaseName';Expression={$_.PSChildName.Replace(".settings","")}}).BaseName
    }
    
    $ProfileCache = Get-AWProfileCache;
    $Results = @{};
    $ResultsAliasMap = @{};
    foreach($settingFile in $settingsFiles){   
        $rollbackFileName = $settingFile.Replace(".settings","");
        $ProfileName = ($ProfileCache.Profiles | where ID -EQ $rollbackFileName)
        $ProfileId = $rollbackFileName;
        If(($ProfileName | measure).Count -EQ 1){
            $ProfileName = $ProfileName.Name
        } Else {
            $ProfileName = $rollbackFileName;
        }
        <#If($ProfileCache){
            If($rollbackFileName -match "[1-9]{1}[0-9]{0,9}"){
                $InstalledProfiles = (($ProfileCache.Profiles | Where Status -IN 3,6) | select Id).Id;
            }
        }#>

        $xmlPath = $airwatchInstallDir + "\AgentUI\Cache\Profiles\$rollbackFileName.xml"
        $archivedFile = $current_path + "\Installed\" + $rollbackFileName + ".keys";

        $Results.Add("$ProfileId","");
        $ResultsAliasMap.Add("CustomAttributes.$ProfileName",$ProfileId);
        Try{
            $InventoryScheme = [IO.File]::ReadAllText("$current_path\Profiles\" + $settingFile);
            if(!($InventoryScheme.Contains("Systems"))){
                $InventoryScheme = ConvertFrom-EncryptedFile $InventoryScheme;
            }
            If($InventoryScheme -notlike "Error: *"){
                $InventoryJSON = ConvertFrom-Json -InputObject $InventoryScheme;
            } Else{
                $Results[$ProfileId] = $InventoryScheme;
                continue
            }
        } Catch{
            $ErrorMessage = $_.Exception.Message;
            Write-Log2 -Path $logLocation "An error has occured. Error: $ErrorMessage" -Level Error
            $Results[$ProfileId] = "An error has occured. Error - $ErrorMessage"
            continue
        }

        if(!($InventoryJSON.Systems)){
            Write-Log2 -Path $logLocation "An error has occured. Error: JSON not in correct format.  The item, Systems, is missing." -Level Error
            $Results[$ProfileId] = "An error has occured. Error- JSON not in correct format.  The item, Systems, is missing."
            continue
        }

        foreach($SystemItem in $InventoryJSON.Systems){
            $Alias = "";
            $SystemName = "";
            $RegKey = "";
            if(!($SystemItem.Name)){
                Write-Log2 -Path $logLocation -Message "An error has occured. Error: JSON not in correct format.  The item, RegKey, in this System name is missing." -Level Error
                continue
            } else {
                $Alias = $SystemItem.Name + ".";
                $SystemName = $SystemItem.Name;
            }
            if($SystemItem.Alias){
                $Alias = $SystemItem.Alias + ".";
            }
            if($SystemItem.RegKey){
                $RegKey = $SystemItem.RegKey;
                if($RegKey -match "HK[A-Za-z]{1,3}:\\(.*)\\$|\\(.*$)"){
                    $regXMLPath = $Matches[2];
                }
            } elseif ($SystemName){
                 $RegKey = "HKLM:\\Software\\AirWatch\\InventorySettings\\$SystemName"; 
                 $regXMLPath = "Software\\AirWatch\\InventorySettings\\$SystemName";
            }
            $CurrentRegKeySet = (Get-Item -Path $RegKey).Property;

            If($SystemItem.CmndletMappings){
                $keyvalues = @{};
                $aliasMap = @{};
                ForEach($CmndletMap in $SystemItem.CmndletMappings){

                    If($Debug){
                        Write-Log2 -Path $logLocation -Message ("Commandlet =" + $CmndletMap.Cmdlet);
                    }

                    #$CmndletResults = iex $CmndletMap.Cmdlet;
                    $CmndletResults = Invoke-ExpressionSafe -Command $CmndletMap.Cmdlet -Debug 1;

                    If($Debug){
                        Write-Log2 -Path $logLocation -Message ($CmndletResults | Format-List | Out-String)
                    }
                   
                    $ResultCount = 0;
                    ForEach($CmndletResult in $CmndletResults){
                        if($CmndletMap.Name){
                            $Namespace = $CmndletMap.Name;
                        } Else { 
                            $Namespace = $SystemName;
                        }
                        $prefix = "";
                        if($Namespace.Contains("#")){       
                            $Namespace = $Namespace.Replace("#",$ResultCount.ToString());
                            $prefix = "$ResultCount.";
                        } elseif (($CmndletResults | measure).Count  -gt 1) {
                            $Namespace = $Namespace + $ResultCount.ToString();
                            $prefix = "$ResultCount.";
                        }
                        if($CmndletMap.PropertyMap){
                            $CmndletMap = $CmndletMap.PropertyMap;
                        }

                        If($CmndletMap.Attributes -or $CmndletMap.CustomAttributes){
                            $AttributeHolder = $CmndletMap.Attributes;
                            If($CmndletMap.CustomAttributes){
                                $AttributeHolder = $CmndletMap.CustomAttributes;
                            } 
                            $CustomAttributes = $AttributeHolder.Split(",");
                            ForEach($CustomAttribute in $CustomAttributes){                       
                                If($CustomAttribute -eq "*"){
                                    $Properties = $CmndletResult | Get-Member | where MemberType -match "Property" | Select-Object -Property Name
                                    ForEach ($Property in $Properties){
                                        $Name = $Property.Name;
                                        try{
                                            
                                            $keyvalues.Add("$prefix$Name", $CmndletResult."$Name");
                                            $aliasMap.Add("$Namespace.$Name","$prefix$Name");
                                        } catch {
                                            $e = $_.Exception.Message;
                                            $i = "$Namespace.$Name";
                                            #return;
                                        }
                                    }
                                } Else{   
                                    $keyvalues.Add("$prefix$CustomAttribute", $CmndletResult."$CustomAttribute");
                                    $aliasMap.Add("$Namespace.$Name","$prefix$CustomAttribute");
                                }   
                            }
                        }

                        If($CmndletMap.FormattedAttributes){
                            $FormattedAttributes = $CmndletMap.FormattedAttributes.PSObject.Properties;
                            ForEach($FormattedAttribute in $FormattedAttributes){
                                $Name = $FormattedAttribute.Name;
                                $Expression = $FormattedAttribute.Value;
                                if(!$Expression -match "\$\(.*\)"){
                                    $Expression = "`$($Expression)"
                                }
                                $ScriptBlock = [scriptblock]::Create( $Expression )
                                $FormattedProperty = $CmndletResult | Select-Object @{ Name = $Name;Expression = $ScriptBlock}
                                if($FormattedProperty){
                                    $FormattedValue = $FormattedProperty."$Name";
                                    $keyvalues.Add("$prefix$Name", $FormattedValue);
                                    $aliasMap.Add("$Namespace.$Name","$prefix$Name");
                                }
                            }
                        }

                        If($CmndletMap.MappedValues){
                            $MappedValues = $CmndletMap.MappedValues | Get-Member | where MemberType -match "Property" | Select-Object -Property Name
                             ForEach($Mappings in $MappedValues){
                                 $Name = $Mappings.Name;
                                 if($CmndletResult."$Name"){
                                    $Val = $CmndletResult."$Name";
                                    if($CmndletMap.MappedValues."$Name"."$Val"){
                                         if($CmndletMap.Name.Contains("#")){
                                             $prefix = "$ResultCount.";
                                         }
                                         If(!$keyvalues.ContainsKey("$prefix$Name")){
                                            $keyvalues.Add("$prefix$Name", $CmndletMap.MappedValues."$Name"."$Val");
                                            $aliasMap.Add("$Namespace.$Name","$prefix$CustomAttribute"); 
                                         } Else {
                                            $keyvalues["$prefix$Name"] = $CmndletMap.MappedValues."$Name"."$Val";
                                         }
                                    }
                                    
                                 }
                             }
                        }

                        $ResultCount++;
                    }
                    
                }
                #Set registry values
                $x = Set-RegistryKeyValue -source $archivedFile -key $RegKey -keyvalues $keyvalues -CVFormatted $true;                      
                    
                $resultString = "Results = ";
                foreach($res in $x.Keys){
                    $resultString += ($res + ":" + $x[$res] + ",")
                }
                Write-Log2 -Path $logLocation $resultString;
                Add-CustomVariables -xmlPath $xmlPath -keypath $regXMLPath -aliasMap $aliasMap -startClean $false;

                #Purge the registry
                $temp = $CurrentRegKeySet | % {if($_ -notin $keyvalues.Keys){return $_}}
                foreach($tempreg in $temp){
                    try{
                        Remove-ItemProperty -Path $RegKey -Name $tempreg -Force;
                    } catch{
                        $ErrorMessage = $_.Exception.Message;
                        Write-Log2 -Path $logLocation -Message $ErrorMessage
                    }
                }
            }
        }
        $Results[$ProfileId] = "SUCCESS - $resultString"
    }
    
    $InstallPath = "HKLM:\Software\AirWatch\ProductProvisioning\CustomSettings"
    $timestamp = (date).ToString("MM-dd-yyyy hh.mm.ss"); 
    $Results.Add("LastScanComplete", $timestamp);
    $ResultsAliasMap.Add("CustomAttributes.LastScan","LastScanComplete");
    Set-RegistryKeyValue -source "CustomSettingModule" -key $InstallPath -keyvalues $Results -CVFormatted $true;
    Add-CustomVariables -xmlPath "CustomSettings.xml" -keyPath "Software\AirWatch\ProductProvisioning\CustomSettings" -aliasMap $ResultsAliasMap;
}


Function Apply-Registry{
    $xmlPath = $airwatchInstallDir + "\AgentUI\Cache\Profiles\awinventory.xml"
    Remove-Item $xmlPath -ErrorAction Ignore;

    #Get setup JSON
    $RegFiles = Get-ChildItem -Path "$current_path\Queue\" -Name "*.reg" 
    $CsvFiles = Get-ChildItem -Path "$current_path\Queue\" -Name "*.csv"

    $TotalRegistryFiles = @{"RegFiles"=$RegFiles;"CsvFiles"=$CsvFiles}

    Write-Log2 -Path $logLocation "$numFiles found.  Processing files now."
    foreach($RegistryFileContainer in $TotalRegistryFiles){
        foreach($RegistryFile in $RegistryFileContainer.Keys){   
            $rollbackFileName = $RegistryFileContainer[$RegistryFile];
            If($rollbackFileName -match "(.*)\.(reg|csv)"){
                $rollbackFileName = $Matches[1];
                $FileType = $Matches[2];
                $archivedFile = $current_path + "\Installed\" + $rollbackFileName + ".keys";

                Switch($FileType) {
                    "reg" {
                        
                    } "csv" {

                    }
                }
            }
        }
    }
}


Switch ($Action){
   "Install" {
        Switch ($InstallType){
            "All" {
                Apply-CustomVariables
            } "Reg" {

            } "CustomVariables" {

            }
        } 
   } "Remove" {

   } "Reconcile" {

   }
}

