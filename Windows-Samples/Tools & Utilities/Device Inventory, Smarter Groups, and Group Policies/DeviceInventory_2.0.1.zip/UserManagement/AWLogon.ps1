﻿<#

#>
$logLocation = "C:\Temp\Logs\UserManagement.log";
$current_path = $PSScriptRoot;
if($PSScriptRoot -eq ""){
    $current_path = "C:\Temp\UserManagement";
}

$InstallPath = "HKLM:\Software\AIRWATCH\ProductProvisioning";
$shared_path = "C:\Temp\Shared"
If(Test-Path $InstallPath){
    $getShared_path = ((Get-ItemProperty -Path $InstallPath).PSObject.Properties | where Name -eq "SharedPath") | Measure;
    If($getShared_path.Count -gt 0){
        $shared_path = Get-ItemPropertyValue -Path $InstallPath -Name "SharedPath";       
    }
} Else { 
    return;
}

Unblock-File "$shared_path\Security-Functions.psm1"
$module = Import-Module "$shared_path\Security-Functions.psm1" -ErrorAction Stop -PassThru -Force;
Unblock-File "$shared_path\AirWatchAPI.psm1"
$apimodule = Import-Module "$shared_path\AirWatchAPI.psm1" -ErrorAction Stop -PassThru -Force;

$log_path = Get-ItemPropertyValueSafe -Path $InstallPath -Name "LogPath" -DefaultVal "C:\Temp\Logs";
$logLocation = "$log_path\UserManagement.log"; 


#Set API content types
$content_type = "application/json;version=1";
$content_type_v2 = "application/json;version=2";

$api_settings_obj = Get-AWAPIConfiguration;

$Server = $api_settings_obj.ApiConfig.Server;
$API_Key = $api_settings_obj.ApiConfig.ApiKey
$Auth = $api_settings_obj.ApiConfig.ApiAuth;
$OrganizationGroupId = $api_settings_obj.ApiConfig.OrganizationGroupId;
$deviceid = $api_settings_obj.ApiConfig.DeviceId;

$device_endpoint = "$server/api/mdm/devices/$deviceid/";
$change_user_endpoint = "$server/api/mdm/devices/$deviceid/enrollmentuser/";
$user_search_endpoint = "$server/api/system/users/search";
$user_details_endpoint = "$server/api/system/users/";

$Headers = @{"Authorization"=$Auth;"aw-tenant-code"=$API_Key;"accept"=$content_type;"content-type"=$content_type};
$Headers_alt = @{"Authorization"=$Auth;"aw-tenant-code"=$API_Key;"accept"=$content_type_v2;"content-type"=$content_type_v2};

$device_info = Invoke-AWApiCommand -Endpoint $device_endpoint -Header $Headers
If($device_info){
   $CurrentUser = Get-CurrentLoggedonUser -ReturnObj $true;
   $CurrentUsername = $CurrentUser.Username;
   If($device_info.Ownership -eq "S" -and $device_info.UserName -ne $CurrentUsername){      
       $user_search = Invoke-AWApiCommand -Endpoint "$user_search_endpoint`?username=$CurrentUsername" -Header $Headers
       If($user_search){
            $domainUsers = $user_search.Users | where {$_.SecurityType -eq 1}
            If(($domainUsers | measure).Count -eq 1){
                $CurrentUserId = $domainUsers[0].Id.Value;
            } Else {
                ForEach($user in $user_search.Users){
                    $CurrentUserIdTest = $user.Id.Value;
                    $get_user = Invoke-AWApiCommand -Endpoint "$user_details_endpoint/$CurrentUserIdTest" -Header $Headers
                    If($get_user){

                    }
                }
            }
            If($CurrentUserId){
                $change_users = Invoke-AWApiCommand -Endpoint "$change_user_endpoint/$CurrentUserId" -Method POST -Header $Headers
            }
       }
   }
}