#Logging information
$logLocation = "C:\Temp\Logs\RegistryModule.log";

#Logging wrapper function in event we cannot load the logging module
function Write-Log2{ #Wrapper function to made code easier to read;
    [CmdletBinding()]
    Param
    (
        [string]$Message,
        [string]$Path=$logLocation,
        [Parameter(Mandatory=$false)]
        [ValidateSet("Error","Warn","Info")]
        [string]$Level="Info"
    )
    if($log){
        Write-Log -LogPath $Path -LogContent $Message -Level $Level;
    } else {
        $DateNow = (Date).ToString("yyyy-mm-dd hh:mm:ss");
        Add-Content $Path "{$DateNow}     {$Level}     {$Message}";
    }
}

#Current file information
$source = "RegistryModule"
$current_version = "1.1.5"

#Get current path
$current_path = $PSScriptRoot;
if($PSScriptRoot -eq ""){
    $current_path = "C:\Temp\Shared\";
}
Unblock-File "$current_path\Utility-Functions.psm1";
$utilitiesModule = Import-Module "$current_path\Utility-Functions.psm1" -ErrorAction Stop -PassThru -Force;

$InstallPath = "HKLM:\Software\AIRWATCH\ProductProvisioning";
If(Test-ItemProperty -Path $InstallPath -Name "LogPath"){
    $logLocation = (Get-ItemPropertyValue -Path $InstallPath -Name "LogPath") + "\RegistryModule.log";        
}

If(!(Test-Path "HKU:")){
    New-PSDrive HKU Registry HKEY_USERS  
}


function Set-RegistryKeyValueNoValidation
{
    param([string]$path, [string]$name, [string]$type, [string]$value)    
        If(!(Test-Path ($path))) {
            $k = Write_Registry_Key -source $source -path $RegPath -key $RegKey;
        }
        Try{
            $r = New-ItemProperty -path $FullPath -name $RegName -value $RegValue -PropertyType $RegType -Force;
        } Catch {
            $errorMessage = $_.ExceptionMessage;
            Write-Log2 -Path $logLocation -Path $logLocation -Message "An error has occured writing to $path. " -Level Error 
            return $false;
        }
        return $r;
    
}

function ConvertTo-CustomVariableSafeString{
    param([string]$input_string)
    $formatter = $input_string;
    If($formatter -match "^[A-Za-z0-9\``\!\@\#\`$\^\(\)\%\-_\+\=\'\,\.]*$"){
        #string is valid
        return $formatter;
    } else {
        $MappedChars = @{"`""="'";"'"="``";"\\"="`,";"\"="`,";"/"="`.";"::"="`!";":"="`!";";"="`%"}
        ForEach($Mapped in $MappedChars.Keys){
            $formatter = $formatter.Replace($Mapped, $MappedChars[$Mapped]);
        }
        If($formatter -match "[A-Za-z0-9\``\!\@\#\`$\^\(\)\%\-_\+\=\'\,\.]*"){
            return $formatter;
        } else {
            $longFormatter = "";
            foreach($char in $formatter){
                if($char -notmatch "[A-Za-z0-9\``\!\@\#\`$\^\(\)\%\-\_\+\=\'\,\.]"){
                    $longFormatter += "`%";
                } else {
                    $longFormatter += $char;
                }
            }
            return $longFormatter
        }
    }
}

function Set-RegistryKeyValue
{
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$false)]
        [string]$source="C:\Temp\Reg\Keys\AuditLog.key",

        [Parameter(Mandatory=$false)]
        [ValidateSet("HKEY_LOCAL_MACHINE","HKEY_CURRENT_USER","HKEY_USER","HKLM:","HKCU:","HKU:")]
        [string]$path,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        #[ValidatePattern("")]
        [string]$key,

        [Parameter(Mandatory=$true,ParameterSetName="SingleValue")]
        [string]$name, 
    
        [Parameter(Mandatory=$false,ParameterSetName="SingleValue")]
        [string]$type, 
        
        [Parameter(Mandatory=$true,ParameterSetName="SingleValue")]
        [string]$value,

        [Parameter(Mandatory=$false,ParameterSetName="SingleValue")]
        [string]$user,

        [Parameter(Mandatory=$true,ParameterSetName="MutlipleValue")]
        $keyvalues=@{},
        #Custom variable formatter
        [Parameter(Mandatory=$false)]
        [bool]$CVFormatted=$false,
        [bool]$isDebug=$false
        )
       
        $results = @{"KeysCreated"=0;"PropertiesCreated"=0;"PropertiesModified"=0;"Errors"=0}

        switch ($psCmdlet.ParameterSetName) {
            "SingleValue"  {
                    if($name -and $value){        
                        $keyvalues = @{$name=$value};
                    }
                }
            "MultiValue"  {#Actions to process for ByUserName
                }
        } 

        $PathParser = Test-RegKeyFormat -Path $path -Key $key -User $user;
        if($PathParser){
            $FullPath = $PathParser["FullPath"];
            $RegPath = $PathParser["RegPath"];
        } else {
            $results["Errors"]++;
            return $results;
        }
        
        #Open HKEY_USER drive for easy parsing
        if($RegPath -eq "HKU" -and (!(Test-Path "HKU:"))){
            New-PSDrive HKU Registry HKEY_USERS;    
        }

        #Iterate through keys and values
        foreach($RegName in $keyvalues.Keys){
            #Determine type
            $RegValue = $keyvalues[$RegName];
            $RegType = "String";
            if($type){
                 $RegType = $type;  
            }
            else{   
                 $typeInformation = Test-RegValueType -object $RegValue;
                 $RegValue = $typeInformation["Value"];
                 $RegType = $typeInformation["Type"];
                 if($isDebug){ 
                    Write-Log2 -Path $logLocation -Message "Determed value as $RegType.";
                }
            }

            if($RegType -eq "String" -and $CVFormatted){
                $RegValue = ConvertTo-CustomVariableSafeString $RegValue;
            }

            $OldValue = "";
            $NewValue = "";
            $RegNameBase = "";
            If(!(Test-Path ($FullPath))) {
                Write-Log2 -Path $logLocation -Message "Key, $FullPath, does not exist.  Creating $FullPath."; 
                $k = New-RegistryKey -source $source -path $FullPath;
                $results["KeysCreated"] += $k["KeysCreated"];
            } Else{
                If(Test-ItemProperty -Path $FullPath -Name $RegName){
                    $OldValue = Get-ItemPropertyValue -Path $FullPath -Name $RegName;
                } Else{
                    $RegNameBase = "-";
                }
            }
            Try{
                if($OldValue -ne $RegValue){
                    $r = New-ItemProperty -path $FullPath -name $RegName -value $RegValue -PropertyType $RegType -Force;
                    If($r){
                        if($RegNameBase.StartsWith("-")){
                            $results["PropertiesCreated"]++;
                        } Elseif ($OldValue -ne ""){
                            $results["PropertiesModified"]++;
                        }
                        #$RegistryAttributes = @{""};
                        $RegNameBase = $RegNameBase + $RegName;
                        $NewValue = "-->" + $RegValue;
                        $newKey = "$FullPath,$RegNameBase,$RegType,$OldValue,$NewValue";
                        Add-Content $source $newKey;
                    }
                }
            } Catch {
                $errorMessage = $_.ExceptionMessage;
                Write-Log2 -Path $logLocation -Message "An error has occured writing to $path. " -Level Error 
                $results["Error"]++;
            }
            
        }
        return $results;
}
   

function New-RegistryKey
{
    param([string]$source, [string]$path, [string]$key, [switch]$recurse=$true, [bool]$isDebug=$false)
    
    $results = @{"KeysCreated"=0;"Errors"=0}
    $RegPath = $path;
    $RegKey = $key;
    if($key){
        $FullPath = $RegPath + $RegKey;
    } else{
        $FullPath = $RegPath;
    }

    If($FullPath -match "(([A-Za-z]{3,4}:)(\\.*)+\\)([^\\]*)"){
        $ParentKey = $Matches[1];
        $NewKey = $Matches[4];
    }    
    $ParentKey = $ParentKey.Substring(0, $ParentKey.Length - 1);
    if($isDebug){ 
        Write-Log2 -Path $logLocation -Message "Attempting to create $NewKey at $ParentKey."; 
    }

    If(!(Test-Path $ParentKey) -and $recurse) {
        if($isDebug){ 
            Write-Log2 -Path $logLocation "Parent key, $ParentKey does not exist.  Recurse flag set, attempting to create." 
        }
        $resultsParent = New-RegistryKey -source $source -path $ParentKey;
        $results["KeysCreated"] = $results["KeysCreated"] + $resultsParent["KeysCreated"];
        $results["Error"] = $results["Error"] + $resultsParent["Error"];
        if($resultsParent["Error"] -gt 0 -and $resultsParent["KeysCreated"] -eq 0){        
            Write-Log2 -Path $logLocation "Error: Parent key not ." -Level Error;
            return $results["Errors"]++;
        }
    } Elseif (!(Test-Path $ParentKey) -and !$recurse){
        Write-Log2 -Path $logLocation "An error occured: Could not create new key becayse parent does not exist and recurse flag not set." -Level Error;
        return $results["Errors"]++;
    } 
    Try{      
        $r = New-Item -Path $ParentKey -Name $NewKey; 
        if($r){  
            Add-Content $source ("-" + $FullPath);
            $results["KeysCreated"]++;
            if($isDebug){ 
                Write-Log2 -Path $logLocation "Key, $NewKey, was created at $Parent." 
            }
        } Else {
            if($isDebug){ 
                Write-Log2 -Path $logLocation "An error occured: Could not create new key." -Level Error;
            }
            $results["Errors"]++;
        }
    } Catch{
        $errorMessage = $_.Exception.Message;
        Write-Log2 -Path $logLocation "An error occured creating $NewKey at $ParentKey : $errorMessage" -Level Error;
        $results["Errors"]++;
    }
    
    return $results;
}


function Remove-RegistryKey
{
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$false)]
        [Alias("Source")]
        [string]$source="C:\Temp\Reg\Keys\AuditLog.key",

        [Parameter(Mandatory=$false)]
        [ValidateSet("HKEY_LOCAL_MACHINE","HKEY_CURRENT_USER","HKEY_USER","HKLM:","HKCU:","HKU:")]
        [Alias('Path')]
        [string]$path,

        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [Alias('Key')]
        [string]$key,

        [Alias('Name')]
        [string]$name, 
        
        [Alias('User')]
        [string]$user,

        [switch]$Recurse,

        [Parameter(Mandatory=$false)]
        [switch]$Force
        
        )
        
        $PathParser = Test-RegKeyFormat -Path $path -Key $key -User $user;
        if($PathParser){
            $FullPath = $PathParser["FullPath"];
            $RegPath = $PathParser["RegPath"];
        } else {
            return;
        }
        
        if($RegPath -eq "HKU" -and (!Test-Path("HKU:"))){
            New-PSDrive HKU Registry HKEY_USERS;    
            $minDepth = 3;
        }
            

        If(Test-Path $FullPath) {
            If($name){
                If(Test-ItemProperty $FullPath $name){
                    Try {
                        Remove-ItemProperty -Path $FullPath -Name $name;
                    } Catch{
                        $ErrorMessage = $_.Exception.Message;
                        Write-Log2 -Path $logLocation "Error deleting value(s) $FullPath.  Access denied, this path is protected." -Level Error;
                    return $false;
                    }
                }
            } Else{
                if(!($FullPath.IndexOf("\", $minDepth)) -and !$Force){
                    Write-Log2 -Path $logLocation "Error deleting path $FullPath.  Access denied, this path is protected." -Level Error;
                    return $false;
                }

                $OldValues = Get-ChildItem $FullPath -Recurse;
                If($OldValues -and $Recurse){
                    
                } ElseIf($OldValues -and !$Recurse) {
                     Write-Log2 -Path $logLocation "Error deleting path $FullPath.  Child objects exist.";
                     return $false;
                } Else {
                   
                }
            }
        } else {
            Write-Log2 -Path $logLocation "An error has occured attemtping to delete $FullPath!$name";
            return $false;  
        }
        If($r){
            $newKey = "$FullPath,$RegName,$RegType,$OldValue"
            Add-Content $source $newKey;
        }
        return $r;
}

function Test-ItemProperty{
    Param([string]$Path, [string]$Name)
    return (Get-Item -Path $Path).GetValue($Name) -ne $null;
}

function Test-RegValueType{
    Param($object)
    $result = @{"Type"="String";"Value"=$object}
    if("$object" -ne ""){
        if(($object | measure).Count -eq 1){ 
            if($object | Test-IsInt){
                $result["Type"] = "Dword";            
            } elseif($object.ToString().ToLower().StartsWith("dword:")){
                $result["Type"] = "Dword"
                $result["Value"] = $object.ToString().Replace("dword:","");
            }
        } else{
            if($object["Type"] -and $object["Value"]){
                $result["Type"] = $object["Type"];
                $result["Value"] = $object["Value"];
            }
        }
    }
    return $result;
}

function Test-RegKeyFormat{
    Param([string]$Path, [string]$Key, [string]$User)

    $FormatError = $false
    $RegKeyResults = @{};
    $RegKeyMatch = @{"HKEY_LOCAL_MACHINE"="HKLM:";"HKEY_CURRENT_USER"="HKCU:";"HKEY_USER"="HKU:"}
    if($Path -and !$Key){
        $FullPath = $Path;
        if(!($FullPath -match "(HK[A-Za-z]{1,3}:|HKEY_[^\\]*)(\\.*)+")){
            $FormatError = $true;
        }
    } elseif($Key -and !$Path){
        $FullPath = $Key;
        if(!($FullPath -match "(HK[A-Za-z]{1,3}:|HKEY_[^\\]*)(\\.*)+")){
            $FormatError = $true;
        }
    } else {
        if($Path -match "(HK[A-Za-z]{1,3}:|HKEY_[^\\]*)(\\.*)+"){
            $FullPath = $Path;
        } elseif($Key -match "(HK[A-Za-z]{1,3}:|HKEY_[^\\]*)(\\.*)+"){
            $FullPath = $Key;
        } elseif(($Path + $Key) -match "(HK[A-Za-z]{1,3}:|HKEY_[^\\]*)(\\.*)+"){
            $FullPath = $Path + $Key;
        } else{
            $FormatError = $true;   
        }
    }

    If($FormatError){
        Write-Log2 -Path $logLocation -Message "Error, registry key path did not match required format.  (Examples: 'HKLM:\Path\To\Key' or 'HKEY_Local_Machine\Path\To\Key)" -Level Error;
        return;
    }
    

    #Get reg key
    if($Matches[1]){
        if($RegKeyMatch.Contains($Matches[1])){
            $FullPath = $FullPath.Replace($Matches[1],$RegKeyMatch[$Matches[1]])
            $RegPath = $RegKeyMatch[$Matches[1]];
        } else {
            $RegPath = $Matches[1];
        }
    }

    #User logic
    if($RegPath -ne "HKLM:"){
        if($RegPath -eq "HKCU:"){
            $UserSID = Get-UserSIDLookup("(current_user)");
            $FullPath = $FullPath.Replace("HKCU:\","HKU:\$UserSID\");
        } elseif($RegPath -eq "HKU:"){
            if($User){
                $UserSID = Get-UserSIDLookup($User);
                $FullPath = $FullPath.Replace("HKU:\","HKU:\$UserSID\");
            } elseif($FullPath -match "HKU:\\%([^%\\]*)%\\"){
                $User = $Matches[1];
                $UserSID = Get-UserSIDLookup($User);
                $FullPath.Replace("%$User%", $UserSID);
            } elseif($FullPath -match "HCU:\\(SID-[0-9\-]*)\\"){
                $UserSID = $Matches[1];
            }
        } else{
            Write-Log2 -Path $logLocation -Message "An invalid registry path was specified. " -Level Error
            return;
        }
        if($sid.BeginsWith("Error:")){
            Write-Log2 -Path $logLocation -Message "An error has occured: $UserSID" -Level Error
            return;
        }
        $RegPath = "HKU:";
    }
        
    #Clean up full path to remove trailing slash
    if($FullPath.EndsWith("\")){
        $FullPath = $FullPath.Substring(0, $FullPath.Length - 1);
    }


    $RegKeyResults.Add("FullPath",$FullPath);
    $RegKeyResults.Add("RegPath",$RegPath);
    if($UserSID){
        $RegKeyResults.Add("UserSID",$UserSID);
    }
    return $RegKeyResults;
}


function Import-RegistryFromCSV
{
    param([string]$path="")
    $RegEntries = import-csv $path

    ForEach ($RegEntry in $RegEntries) {
            $RegKey = $($RegEntry.Key)
            $RegName = $($RegEntry.Name)
            $RegType = $($RegEntry.Type)
            $RegValue = $($RegEntry.Value)
            $FullPath = $RegPath + $RegKey

            Set-RegistryKeyValue -key $RegKey -name $RegName 
    }
}

function Import-FromReg
{
    param([string]$path="",[string]$source)
    
    $RegEntries = Get-Content $path;
    $RegKeyMatch = @{"HKEY_LOCAL_MACHINE"="HKLM:";"HKEY_CURRENT_USER"="HKCU:";"HKEY_USER"="HCU:"}
    $currentPath = "";
    ForEach ($RegEntry in $RegEntries) {
        if($RegEntry -match "\[((HKEY_[^\\]*)(\\[^;]*))\].*"){
            $Path = $RegKeyMatch[$Matches[2]];
            $Key = $Matches[3];   
            $CurrentPath = $Path + $Key;
        } elseif($RegEntry -match "\[-((HKEY_[^\\]*)(\\[^;]*))\].*"){
            $Path = $RegKeyMatch[$Matches[2]];
            $Key = $Matches[3];   
            if(!(Test-Path ($Path + $Key))){
                
            }
            Remove-RegistryKey -source
        } elseif($RegEntry -match '"([^";]*)"=("([^;]*)"|dword:([0-9]{1,8}))'){
            $Property = $Matches[1];
            if($Matches[3]){
                $Type = "String";
                $Value = $Matches[3];
            } elseif ($Matches[4]){
                $Type = "Dword";
                $Value = $Matches[4];
            }  
        } elseif($RegEntry -match '"([^";]*)"=-[^;]*'){
            $Property = $Matches[1];  
        }


    } 
}


function Import-FromKey
{
    param([string]$path="")    
    $RegEntries = Get-Content $path;      
    ForEach ($RegEntry in $RegEntries) {
        If(!$RegEntry.StartsWith("#")){
            $Line = $RegEntry.Split(".");
            $key = $RegEntry[0];       
        }   
    }
}



$XMLTemplateIF = @'
<xml version="1.0">
<wap-provisioningdoc name="System Info /V_1">
	<characteristic type="com.windowspc.getregistryinfo.managed">
		<reg_value value_name="valuename" key_name="keyname" custom_attribute_name="caname"/>
	</characteristic>
	
</wap-provisioningdoc>
</xml>
'@

function Add-CustomVariable{
    param([string]$xmlPath, [string]$value_name, [string]$attribute_name, [string]$key_name)

   
    If(Test-Path $xmlPath){
        [xml]$XmlDocument = Get-Content -Path $xmlPath 
    } else {
        [xml]$XmlDocument = $XMLTemplateIF;
    }

    $xmlItem = $XmlDocument.xml.'wap-provisioningdoc';
    
    $Current_Item = $xmlItem.ChildNodes.Where({$_.reg_value.value_name -eq "valuename"})
     
    $x = $xmlItem.ChildNodes[0].Clone();
    $x.reg_value.value_name = $value_name;
    $x.reg_value.key_name = $key_name;
    $x.reg_value.custom_attribute_name = $attribute_name;

    $XmlItem.AppendChild($x);

    $xmlPath_Path = $xmlPath.Substring(0,$xmlPath.LastIndexOf("\"));
    if(!(Test-Path $xmlPath_Path)){
        mkdir $xmlPath_Path
    }

    $XmlDocument.Save($xmlPath);
    return $false;
}

function Add-CustomVariables{
    param([string]$xmlPath, [string]$keyPath, $aliasMap=@{},[bool]$startClean=$false)

    If($xmlPath.Contains("\")){
        #Make sure legacy values are supported
    } ElseIf($xmlPath -match "[^\\\.]*(?:.xml|$)"){
        $airwatchInstallDir = Get-ItemPropertyValueSafe -Path "HKLM:\Software\AIRWATCH" -Name "INSTALLDIR" -DefaultVal "C:\Program Files (x86)\AirWatch";
        $xmlPath = $airwatchInstallDir + "\AgentUI\Cache\Profiles\$xmlPath";
        if(!($xmlPath.Contains(".xml"))){
            $xmlPath += ".xml";
        }
    }

    $Rebuild = $false;
    if($startClean -and (Test-Path $xmlPath)){
        Remove-Item $xmlPath -Force;
        $Rebuild = $true;
    } else {    
        If(Test-Path $xmlPath){
            [xml]$XmlDocument = Get-Content -Path $xmlPath
            $xmlItem = $XmlDocument.xml.'wap-provisioningdoc';
            $regKeyCheck = ((($xmlItem.ChildNodes | select reg_value).reg_value | where {$_.key_name -eq $keyPath} | measure).Count -gt 0)
            if($regKeyCheck){
                $XmlMapObj = @();
                $Items = ($xmlItem.ChildNodes | select reg_value).reg_value | 
                    % { if($_.custom_attribute_name -ne "caname") { $x = New-Object -TypeName PSCustomObject -Property @{ "valueKey"=( $_.custom_attribute_name + "!" + $_.value_name)};
                     $XmlMapObj += $x; }};
                $AliasMapObj = $aliasMap.Keys | Select-Object @{Name="valueKey";Expression={$_ + "!" + $aliasMap[$_]}};
                $NewItems = $AliasMapObj | Where-Object valueKey -notin $XmlMapObj.valueKey;
                If(($NewItems | Measure).Count -gt 0){
                    Remove-Item $xmlPath -Force;
                    $Rebuild = $true;
                }
            }
        } Else {
            $Rebuild = $true;
        }
    }

    If($Rebuild){
        ForEach($alias in $aliasMap.Keys){
            Add-CustomVariable -xmlPath $xmlPath -value_name $aliasMap[$alias] -attribute_name $alias -key_name $keyPath
        }
    }
}

Function Remove-CustomSettingsProfile{
    param([string]$XMLFile)
    [xml]$XmlDocument = Get-Content -Path $XMLFile
    $xmlItem = $XmlDocument.xml.'wap-provisioningdoc';
    $regKeyCheck = ($xmlItem.ChildNodes | select reg_value).reg_value | where {$_.key_name -ne 'keyname'}
    If($regKeyCheck){
        If(Test-Path $regKeyCheck[0].key_name){
            $valuesnames = (($xmlItem.ChildNodes | select reg_value).reg_value | select value_name).value_name
            $CurrentRegKeySet = (Get-Item -Path $regKeyCheck[0].key_name).Property;
            $temp = $CurrentRegKeySet | % {if($_ -notin $value_name){return $_}}
            foreach($tempreg in $temp){
                try{
                    Remove-ItemProperty -Path $RegKey -Name $tempreg -Force;
                } catch{
                    $ErrorMessage = $_.Exception.Message;
                    Write-Log2 -Path $logLocation -Message $ErrorMessage
                }
            }
        }
        
    }
}

add-type -Language CSharp @'
    public class Helpers {
        public static bool IsInt(object o) {
            int o2;
            if(int.TryParse(o.ToString(), out o2)){
                return true;
            }
            return o is short  || o is int  || o is long || o is uint;
        }
    }       
'@


filter Test-IsInt {
    [Helpers]::isInt($_)
}