﻿#Get current path
$current_path = $PSScriptRoot;
if($PSScriptRoot -eq ""){
    $current_path = "C:\Temp\Shared";
}
if(Test-Path "$current_path\api-debug.config"){
    $useDebugConfig = $true;
}

$logLocation = "C:\Temp\Logs\AirWatchAPI.log";

function Test-ItemProperty{
    Param([string]$Path, [string]$Name)
    return (Get-Item -Path $Path).GetValue($Name) -ne $null;
}

#Import library
$source = $current_path + "\Installed\" + $source + ".keys"

#Set common folder locations 
$InstallPath = "HKLM:\Software\AIRWATCH\ProductProvisioning";
$sharedPath = "C:\Temp\Shared"
If(Test-Path -Path $InstallPath){
    $getSharedPath = ((Get-ItemProperty -Path $InstallPath).PSObject.Properties | where Name -eq "SharedPath") | Measure;
    If($getSharedPath.Count -gt 0){
        $sharedPath = (Get-ItemPropertyValue -Path $InstallPath -Name "SharedPath");       
    }
}

#Import Libraries and Functions
Try{
    Unblock-File "$sharedPath\Utility-Functions.psm1"
    $module = Import-Module "$sharedPath\Utility-Functions.psm1" -ErrorAction Stop -PassThru -Force;
} Catch{    
    $ErrorMessage = $_.Exception.Message;
    Write-Log2 -Path $logLocation -Message "An error has occurrred.  Error: $ErrorMessage"
}  

$log_path = Get-ItemPropertyValueSafe -Path $InstallPath -Name "LogPath" -DefaultVal "C:\Temp\Logs";
$logLocation = "$log_path\AirWatchAPI.log";  
    
function Invoke-AWApiCommand{
    param([string]$Endpoint, [string]$Method="GET", $Headers, $Data, [bool]$Debug=$false)
    try{
       
        $WebRequest = Invoke-WebRequest -Uri ("$Endpoint") -Method $Method -Headers $Headers -Body $Data -UseBasicParsing;
        If($Debug){
            Write-Log2 -Path $logLocation -Message "Connecting to: $Endpoint";
            If($WebRequest.Content){
                Write-Log2 -Path $logLocation -Message $WebRequest.Content;
            }
        }
        if($WebRequest.StatusCode -lt 300){
           $ReturnObj = New-Object -TypeName PSCustomObject -Property @{"StatusCode"=$WebRequest.StatusCode};
           If($WebRequest.Content){
               $ReturnObj = ConvertFrom-Json($WebRequest.Content); 
               if($ReturnObj.Total){
                    if($ReturnObj.Total -gt ($ReturnObj.PageSize * ($ReturnObj.Page + 1))){
                        $ReturnObjPaged = @{0=$ReturnObj;}
                        While($ReturnObj.Total -gt ($ReturnObj.PageSize * $ReturnObj.Page)){
                            if($Endpoint -match "(.*)?"){
                                $Page_Endpoint = $Endpoint + "&page=" + ($ReturnObj.Page + 1).ToString();
                            }
                            $WebRequest = Invoke-WebRequest -Uri ("$Endpoint") -Method $Verb -Headers $Headers -Body $Data -UseBasicParsing;
                            if($WebRequest.StatusCode -eq 200){
                                 $ReturnObj = ConvertFrom-Json($WebRequest.Content); 
                                 $ReturnObjPaged.Add($ReturnObj.Page, $ReturnObj);
                            }
                        }
                    }
               }
           } 
           return $ReturnObj;
        }
        else {
           return $WebRequest.Content;
        }
    } Catch {
        $ErrorMessage = $_.Exception.Message;
        If($Debug){
            Write-Log2 -Message "An error has occurrred.  Error: $ErrorMessage"
        }
        if($_.Exception -like "Unable to connect to the remote server"){
            return "Offline";
        } 
        return;
    }
}

function ConvertTo-EncryptedFile{
    param([string]$FileContents)
    Try{
        $secured = ConvertTo-SecureString -String $FileContents -AsPlainText -Force;
        $encrypted = ConvertFrom-SecureString -SecureString $secured
    } Catch {
        $ErrorMessage = $_.Exception.Message;
        Write-Log2 -Path $logLocation -Message "An error has occurrred.  Error: $ErrorMessage"
        return "Error";
    }
    return $encrypted;
}

function ConvertFrom-EncryptedFile{
    param([string]$FileContents)
    Try{
        $decrypter = ConvertTo-SecureString -String $FileContents.Trim() -ErrorAction Stop;
        $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($decrypter)
        $api_settings = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
    } Catch {
        $ErrorMessage = $_.Exception.Message;
        Write-Log2 -Path $logLocation -Message "An error has occurrred.  Error: $ErrorMessage"
        return "Error: $ErrorMessage";
    }
    return $api_settings
}

function Get-AWAPIConfiguration{
    if(!$useDebugConfig){
        $api_config_file = [IO.File]::ReadAllText("$current_path\api.config");
        if($api_config_file.Contains('"ApiConfig"')){
            $api_settings = $api_config_file;
            $encrypted = ConvertTo-EncryptedFile -FileContents $api_config_file;
            if($encrypted){
                Set-Content -Path ("$current_path\api.config") -Value $encrypted;
            }
        } else {
            $api_settings = ConvertFrom-EncryptedFile -FileContents $api_config_file;
        }
    } else {
          $api_config_file = [IO.File]::ReadAllText("$shared_path\api-debug.config");
          $api_settings = $api_config_file;
    }
    $api_settings_obj = ConvertFrom-Json -InputObject $api_settings

    $Server = $api_settings_obj.ApiConfig.Server;
    $API_Key = $api_settings_obj.ApiConfig.ApiKey
    $Auth = $api_settings_obj.ApiConfig.ApiAuth;
    $OrganizationGroupId = $api_settings_obj.ApiConfig.OrganizationGroupId;

    $Headers = @{"Authorization"=$Auth;"aw-tenant-code"=$API_Key;"accept"=$content_type;"content-type"=$content_type};

    #DeviceId Getter
    If(![bool]($api_settings_obj.ApiConfig.PSobject.Properties.name -match "DeviceId")) {
        $api_settings_obj.ApiConfig | Add-Member -MemberType NoteProperty -Name "DeviceId" -Value -1;
    } Else {
        If($api_settings_obj.ApiConfig.DeviceId -ne ""){
           $deviceid = $api_settings_obj.ApiConfig.DeviceId;
        }
    } 

    If(!($deviceid)) {
        $serialSearch = wmic bios get serialnumber
        $serialnumber = $serialSearch[2]
        $serialnumber = $serialnumber.Trim();

        $serialEncoded = [System.Web.HttpUtility]::UrlEncode($serialnumber);
        $deviceSearchEndpoint = "$server/api/mdm/devices?searchBy=Serialnumber&id=$serialEncoded";

        $device_json = Invoke-AWApiCommand -Endpoint ("$deviceSearchEndpoint") -Headers $Headers;
        If($device_json.Id){
            $deviceid = $device_json.Id.Value;
        } 
    
        if($deviceid){
            if(!$useDebugConfig){
                #Add device Id to local DB to optimize call
                $api_settings_obj.ApiConfig.DeviceId = $deviceid;
                $api_settings = ConvertTo-Json -InputObject $api_settings_obj;
                $encrypted = ConvertTo-EncryptedFile -FileContents $api_settings;
                if($encrypted){
                    Set-Content -Path ("$current_path\api.config") -Value $encrypted;
                }
           
            } else {
                $api_settings_obj.ApiConfig.DeviceId = $deviceid;
                $api_settings = ConvertTo-Json -InputObject $api_settings_obj;
                if($api_settings){
                    Set-Content -Path ("$current_path\api-debug.config") -Value $api_settings;
                }
            }
        }
    }

    return $api_settings_obj;
}

Function Get-AWProfileCache{
    $ProfileCache = Get-ItemPropertyValueSafe -Path $InstallPath -Name "ImportCustomSettings-Path" -DefaultVal "C:\Temp\Reg";
    If(Test-Path "$ProfileCache\Profiles\InstallList.db"){
        $ReadFile = [IO.File]::ReadAllText("$ProfileCache\Profiles\InstallList.db");
        If($ReadFile){
            If(!($ReadFile.contains("`s"))){
                $Unencrypted = ConvertFrom-EncryptedFile -FileContents $ReadFile;
                if($Unencrypted -and $Unencrypted -ne "Error"){
                   #Do nothing 
                } else {
                   return @();
                }
            } Else {
                $Unencrypted = $ReadFile;
            }
        } 
        $Profiles = ConvertFrom-Json $Unencrypted;
        return $Profiles;
    }
    return @();
}