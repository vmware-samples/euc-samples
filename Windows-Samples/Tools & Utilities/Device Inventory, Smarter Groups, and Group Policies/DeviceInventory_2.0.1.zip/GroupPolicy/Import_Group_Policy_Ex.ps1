<#
    Copyright [2017] [Chase Bradley]
#>
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$false)]
    [ValidateSet("Import","Remove","Reconcile")]
    [string]$Action="Import",
    [string]$GPFile,
    [switch]$NoReconcile,
    [bool]$Lockdown=$false
)

#Test to see if we are in Dev Mode
$current_path = $PSScriptRoot;
if($PSScriptRoot -eq ""){
    $current_path = "C:\Temp\GroupPolicy";
}

#Import main module
$modulePath = "$current_path\Import_Types_Ex.psm1";
Unblock-File $modulePath;
$module = Import-Module $modulePath -ErrorAction Stop -PassThru -Force;

$InstallPath = "HKLM:\Software\AIRWATCH\ProductProvisioning";
$shared_path = Get-ItemPropertyValueSafe -Path $InstallPath -Name "SharedPath" -DefaultVal "C:\Temp\shared";
$log_path = Get-ItemPropertyValueSafe -Path $InstallPath -Name "LogPath" -DefaultVal "C:\Temp\Logs";
$logLocation = "$log_path\GroupPolicyLogs.log";        

#These are the designated folders to process the .CSV files
$cache = "$current_path\Queue";
If(!(Test-Path $cache)){
    New-Item -Path "$current_path\Queue" -ItemType Directory -Force
} 

If(!(Test-Path $cache)){
    New-Item -Path "$current_path\Audit" -ItemType Directory -Force
}


Function Import-GroupPolicyFiles{
    param([switch]$NoReconcile)
    #Check for uninstall requests
    $commands = "C:\Temp\Reg\Profiles\InstallList.db";
    If(Test-Path $commands){
        Invoke-ProcessCommands $commands
    }

    #Configure supported file types
    #Currently only supports CSVs from the export and Zip files containing the exports
    $supportedFileTypes = @("txt");

    Write-Log2 -Path $logLocation -Message "Beginning Import Group Policy"
    #Main thread
    $fileProcessor = @{}
    $processZip = 0;

    $processing = Get-ChildItem $cache -Recurse
    ForEach ($policyFileSys in $processing) { 
	    $policyFile = $policyFileSys.FullName;
        Write-Log2 -Path $logLocation -Message ("Parsing file: " + $policyFileSys.FullName)
        if($policyFileSys.Extension -eq ".txt"){
            #Modern import
            $parse = Start-ImportGPOFromLGPO -policyFile $policyFile;
        } else {
            continue;
        }
        if($parse -eq 1){
            Remove-Item $policyFile;
        }
    }
    Invoke-GetCurrentGPO;
}

Function Initialize-Reconcile{
     Start-ReconcileUserAccess;
}

Add-Type @"
using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace Win32.API {

    public class GroupPolicy {

        public GroupPolicy(){}
        [DllImport("Userenv.dll", SetLastError=true)]
        public static extern bool RefreshPolicyEx(
            bool bMachine,
            string dwOptions
           );


        public bool RefreshMachinePolicy(){
            if(RefreshPolicyEx(true, "RP_FORCE")){
                return RefreshPolicyEx(false, "RP_FORCE");
            }
            return false;
        }
        
        
    }
}
"@;

Function Initialize-GPRefresh{
    #Force GPUpdates
    Write-Log2 -Path $logLocation -Message "Import complete.  Updating gpt.ini files."
    Try{
        $GroupPolicy = New-Object Win32.API.GroupPolicy;
        $UseGPUpdate = $GroupPolicy.RefreshMachinePolicy();
    } Catch{

    }
    if(!$UseGPUpdate){
        GPUpdate.exe /force
    }
}

Function Remove-GroupPolicyFile{
    param(
        [string]$Group_Policy_File
    )
    Remove-PoliciesByFile -Filename $Group_Policy_File;
}


Switch ($Action){
    "Import" {
        Import-GroupPolicyFiles;
    } "Remove" {
        Remove-GroupPolicyFile -gpfile $Group_Policy_File;
    } "Reconcile" {
        Initialize-Reconcile;
    }
}

Initialize-GPRefresh;