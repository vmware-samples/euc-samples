<#
#>

<#
==============================================================
Module Header
==============================================================
#>

$logLocation = "C:\Temp\Logs\GroupPolicyLogs.log";

$current_path = $PSScriptRoot;
#Test to see if we are in Dev Mode
if($PSScriptRoot -eq ""){
    $current_path = "C:\Temp\GroupPolicy";
}
   
$InstallPath = "HKLM:\Software\AIRWATCH\ProductProvisioning";
$sharedPath = "C:\Temp\Shared"
If(Test-Path -Path $InstallPath){
    $getSharedPath = ((Get-ItemProperty -Path $InstallPath).PSObject.Properties | where Name -eq "SharedPath") | Measure;
    If($getSharedPath.Count -gt 0){
        $sharedPath = (Get-ItemPropertyValue -Path $InstallPath -Name "SharedPath");       
    }
}
Unblock-File "$sharedPath\AirWatchAPI.psm1";
$apiModule = Import-Module "$sharedPath\AirWatchAPI.psm1" -ErrorAction Stop -PassThru -Force

$log_path = Get-ItemPropertyValueSafe -Path $InstallPath -Name "LogPath" -DefaultVal "C:\Temp\Logs";
$logLocation = $log_path + "\GroupPolicyLogs.log";        
        
#Unblock-File "$sharedPath\Utility-Functions.psm1";
#$utilitiesModule = Import-Module "$sharedPath\Utility-Functions.psm1" -ErrorAction Stop -PassThru -Force

Unblock-File "$sharedPath\Security-Functions.psm1";
$securityModule = Import-Module "$sharedPath\Security-Functions.psm1" -ErrorAction Stop -PassThru -Force

Unblock-File "$sharedPath\Update-Registry.psm1";
$updateRegistryModule = Import-Module "$sharedPath\Update-Registry.psm1" -ErrorAction Stop -PassThru -Force

Unblock-File "$current_path\LGPO.exe";    

#These are the designated folders to process the .CSV files
$errorP = "$current_path\Audit";
$AuditDatabase = "$current_path\Audit\AuditDB_Ex.db";

#Usermap to store and maintain SID list so we don't have to look them up
$UserMap = @{};

#Import Libraries and Functions
$log = $false;


<#
==============================================================
Module Body
==============================================================
#>

function Invoke-LGPO{
    param([string]$LGPOArgs)
    $pinfo = New-Object System.Diagnostics.ProcessStartInfo
    $pinfo.FileName = "$current_path\LGPO.exe"
    $pinfo.RedirectStandardError = $true
    $pinfo.RedirectStandardOutput = $true
    $pinfo.UseShellExecute = $false
    $pinfo.CreateNoWindow = $true;
    $pinfo.Arguments = $LGPOArgs;
    $p = New-Object System.Diagnostics.Process
    $p.StartInfo = $pinfo
    $p.Start() | Out-Null
    $p.WaitForExit(10000)
    $stdout = $p.StandardOutput.ReadToEnd()
    $stderr = $p.StandardError.ReadToEnd()
    if($p.ExitCode -eq 0){   
        $returnVar = $stdout;
        return $returnVar;
    } else {
        return $stderr;
    }
}

function ConvertFrom-LGPOResults{
    param([string]$LGPOContents)
    
    $Entries = @();
    $Lines = $LGPOContents -split "`r`n`r`n";
    $i = 0;
    ForEach($Line in $Lines){
        If($Line -and $Line -notlike ";*"){
            If($Line -match "(Computer|User\:[^\r\n]*|User)\r\n([^\r\n]*)\r\n([^\r\n]*)\r\n([^:]*)(?:\:(.*)|$)"){
                $EntryParse = $Line -split "`r`n";
                if($EntryParse.Length -eq 4){
                    $Entry = $EntryParse[3].Split(":");
                    $Context = $EntryParse[0];
                    $UID = "$Context`::" + $EntryParse[1] + "!" + $EntryParse[2]
                    #$HashedUID = Get-Hash $UID
                    $Properties = @{"UID"=$UID;"Context"=$EntryParse[0];"Key"=$EntryParse[1];
                     "ValueName"=$EntryParse[2];"Type"=("REG_" + $Entry[0]);"Value"=$Entry[1]}
                }
                #Make sure that the Context Exists in the database  
                $Entry = New-Object -TypeName PSCustomObject -Property $Properties; 
                $Entries += $Entry;
            } ElseIf ($Line -match "([^\t]*)\t([^\t]*)\t([^\t]*)\t([^\t]*)\t([^\t]*)$"){
                $LGPOLineMatches = $Matches;
                If($LGPOLineMatches[1] -like "Computer Configuration*"){
                    $Context = "Computer"
                } Else {
                    $Context = "User";
                    if($LGPOLineMatches[1] -match ".*user\s(.*)$"){
                        $Context += ":" + $Matches[1];
                    }
                }
                $UID = "$Context`::" + $LGPOLineMatches[2] + "!" +  $LGPOLineMatches[3];
                #$HashedUID = Get-Hash $UID
                $Properties = @{"UID"=$UID;"Context"=$Context;"Key"=$LGPOLineMatches[2];
                    "ValueName"=$LGPOLineMatches[3];"Type"=$LGPOLineMatches[4];"Value"=$LGPOLineMatches[5]}
                $Entry = New-Object -TypeName PSCustomObject -Property $Properties;
                $Entries += $Entry;
            }
            
        }
    }
    return $Entries;
}


<#
Function: Set-FileMetaData
Author  : cbradley@vmware.com
Description : Lists permissions of an object
Input Params: N/A, Output: String
Example: Set-FileMetaData
        logs permissions in secuirtyAudit.log 
#>
function Get-AliasMap{
    param(
        [string]$FormatedFileName,
        [string]$FormatedRegistryLocation,
        $KeyValues
    )
    $AliasMap = @{};
    
    foreach($KVKey in $KeyValues.Keys){
        $AliasMap.Add("GPO.$FormatedFileName.$KVKey",$KVKey)
    }

    If(!(Test-Path $FormatedRegistryLocation)){
        $nrk = New-RegistryKey -source $FormatedFileName -path $FormatedRegistryLocation;       
    }
    $nrkv = Set-RegistryKeyValue -source $FormatedFileName -key $FormatedRegistryLocation -keyvalues $KeyValues;
    return $AliasMap;
}

if(Test-Path -Path $AuditDatabase){
    $AuditDBJson = [IO.File]::ReadAllText($AuditDatabase);
    $AuditDB_Main = ConvertFrom-JSON -InputObject $AuditDBJson;
} else{
    $AuditDB_Main = New-Object PSCustomObject -Property @{"Profile"=@()}
}

Function Get-AuditDatabaseContext{
    param(
        [string]$Profile
    )
    $ContextSearch = $AuditDB_Main.Profile | where {$_.Name -eq $Profile};
    if($ContextSearch){
        return $ContextSearch;
    }
    return $false;
}

Function Add-AuditDatabaseContext{
    param(
        [string]$ProfileId,
        [string]$Profile
    )

    if(!($AuditDB_Main.Profile | where {$_.Name -eq $Profile})){
        $ContextProperties = @{"Name"=$Profile;"Entries"=@()}
        $ContextObj = New-DynamicObject -Properties $ContextProperties;

        $AuditDB_Main.Profile += $ContextObj;
        $AuditProfile = ([Collections.Generic.List[Object]]$AuditDB_Main.Profile).Find({$args[0].Name -eq $Profile});
        return $AuditProfile;                
    }
    return $false;
}

Function Get-AuditProfileList{
     $Audit_Profiles = @(); 
     ForEach($Prof in $AuditDB_Main.Profile){
        $Audit_Profiles += $Prof.Name;
     }
     return $Audit_Profiles;
}

Function Get-AuditEntries{
    param(
        [string]$Profile="",
        [string]$Key,
        [string]$Search
    )
    $Entries = @{}; 
    Try{
        If($Profile){
            $iProfile = ([Collections.Generic.List[Object]]$AuditDB_Main.Profile).FindIndex({$args[0].Name -eq $Profile});
            $Entries.Add($Profile, ([Collections.Generic.List[Object]]$AuditDB_Main.Profile[$iProfile].Entries).FindAll({$args[0]."$Key" -eq "$Search"}));
        } Else {
            ForEach($Prof in $AuditDB_Main.Profile){
                $TempEntries = ([Collections.Generic.List[Object]]$Prof.Entries).FindAll({$args[0]."$Key" -eq "$Search"})
                ForEach($TempEntry in $TempEntries){
                    If(!($Entries.ContainsKey($Prof.Name))){
                        $Entries.Add($Prof.Name, @());
                    }
                    $Entries[$Prof.Name] += $TempEntry;
                }
            }
        }
    } Catch {
        $ExceptionMessage = $_.Exception.Message;
    }
    return $Entries;
}

Function Get-RegistryKey{
    param([object]$Entry)
    $RegKey = "";
    If($Entry.Context){
        $Context = $Entry.Context;
        $Key = $Entry.Key;
        $ValueName = $Entry.ValueName;
    
        If($Context -eq "Computer"){
            $RegKey = "HKLM:\$Key!$ValueName";
        } ElseIf ($Context -eq "User"){
            $RegKey = "HCU:\$Key!$ValueName";
        } ElseIf ($Context -match "User\:(.*)"){
            if($SIDList.ContainsKey($Matches[1])){
                $SID = $SIDList[$Matches[1]];
            }
            $RegKey = "HKU:\${sid}\$Key!$ValueName";
        } 
    }
    return $RegKey;
}


<#
Function: Start-RecordAudit
Author  : cbradley@vmware.com
Description : Fixes errors and any outside changes
Input Params: N/A, Output: String
Example: Start-ReconcileGPOs
        logs permissions in secuirtyAudit.log 
#>
Function Start-RecordAudit{
    param([array]$CurrentValues)
    
    if(Test-Path -Path $AuditDatabase){
        $AuditDBJson = [IO.File]::ReadAllText($AuditDatabase);
        $AuditDB_Main = ConvertFrom-JSON -InputObject $AuditDBJson;
    } else{
        $AuditDB_Main = New-Object PSCustomObject -Property @{"Profile"=@()}
    }


    $GPOPath = "HKLM:\Software\AirWatch\GroupPolicy\Audit";
    $AliasPath = "Software\AirWatch\GroupPolicy\Audit"

    If(!(Test-Path "HKU:")){
        New-PSDrive HKU Registry HKEY_USERS  
    }

    $GPOPrefix = "GPOAudit.";
    $FileNameCount = @{};
    $RegistryKeys = @();
    $GPOReport = @{};
    $GPOReportAlias = @{};
    ForEach($Entry in $CurrentValues){
        $AuditEntries = Get-AuditEntries -Key "UID" -Search $Entry.UID;
        If($AuditEntries){
            ForEach($ProfileObj in $AuditEntries.Keys){
                $ProfileId = $ProfileObj;
                If(!$FileNameCount.ContainsKey($ProfileId)){
                    $FileNameCount.Add($ProfileId, 0);
                }
                ForEach($AuditEntry in $AuditEntries[$ProfileId]){
                    #Get Audit information              
                    $AuditRegKeyName = "Profile $ProfileId." + $FileNameCount[$ProfileId]; 
                    $AuditValue = $AuditEntry.Context + "@" + $AuditEntry.ValueName + " = " + $AuditEntry.Value;
                    #Fix value for compatability
                    $AuditValue = $AuditValue;

                    $GPOAlias = "$GPOPrefix$AuditRegKeyName"
                    $GPOReport.Add($AuditRegKeyName, $AuditValue);
                    $GPOReportAlias.Add($GPOAlias, $AuditRegKeyName);

                    #Get Reg Key for protection
                    $RegKey = Get-RegistryKey $AuditEntry;
                    If($RegKey){
                       $RegistryKeys += $RegKey;
                    }
                    $FileNameCount[$ProfileId]++;
                }       
            }
        } else {
            #Get Audit information 
            if(!($FileNameCount.ContainsKey("Unmanaged"))){
                $FileNameCount.Add("Unmanaged",0);
            }             
            $AuditRegKeyName = "Unmanaged." + $FileNameCount["Unmanaged"]; 
            $AuditValue = $Entry.Context + "@" + $Entry.ValueName + " = " + $Entry.Value;
            #Fix value for compatability
            $AuditValue = $AuditValue;

            $GPOAlias = "$GPOPrefix$AuditRegKeyName"
            $GPOReport.Add($AuditRegKeyName, $AuditValue);
            $GPOReportAlias.Add($GPOAlias, $AuditRegKeyName);

            #Get Reg Key for protection
            $RegKey = Get-RegistryKey $Entry;
            If($RegKey){
                $RegistryKeys += $RegKey;
            }
            $FileNameCount["Unmanaged"]++;
        }
    }
    $x = Set-RegistryKeyValue -source "RegKeyAudit" -key $GPOPath -keyvalues $GPOReport -CVFormatted $true;                                               
    Add-CustomVariables -xmlPath "RegKeyAudit" -keypath $AliasPath -aliasMap $GPOReportAlias -startClean $true;

}

Function Invoke-GetCurrentGPO{   
    $PolPaths = @{};
    $SystemPolPaths = Get-ChildItem -Path "$env:systemroot\System32\GroupPolicy\"  -Recurse -Force -Filter "registry.pol"
    $UserCount = 0;
    $MachineCount = 0;
    foreach($SystemPolFile in $SystemPolPaths){
        $ContextPath = $SystemPolFile.Directory.Name;
        if($ContextPath -eq "User"){
            $PolPaths.Add("User$UserCount", $SystemPolFile.FullName);
            $UserCount++;
        } elseif ($ContextPath -eq "Machine"){
            $PolPaths.Add("Machine$MachineCount", $SystemPolFile.FullName);
            $MachineCount++;
        }
    }

    $UserRegPaths = Get-ChildItem "$env:systemroot\System32\GroupPolicyUsers\" -Recurse -Force -Filter "*.pol";
    $SIDList = @{};
    foreach($UserPolFile in $UserRegPaths){
        $UserSID = $UserPolFile.DirectoryName;
        $UserSID = $UserSID.Replace("$env:systemroot\System32\GroupPolicyUsers\","").Replace("\User","");
        $UserName = Get-ReverseSID $UserSID;
        if(!($UserName.Contains("Error"))){
            $PolPaths.Add("User:$UserName", $UserPolFile.FullName);
            $SIDList.Add("User:$UserName", $UserSID);
        }
    }

    $CurrentValues = @();
    foreach($ContextVal in $PolPaths.Keys){
        $ContextPath = $PolPaths[$ContextVal];
        if($ContextVal -like "Machine*"){
            $Policies0 = Invoke-LGPO -LGPOArgs "/parse /m $ContextPath"
        } elseif($ContextVal -match "User\!(.*)"){
            $UserName = $Matches[1];
            $Policies0 = Invoke-LGPO -LGPOArgs "/parse /u:$UserName $ContextPath";
        } elseif($ContextVal -match "User[0-9]{0,3}"){
            $Policies0 = Invoke-LGPO -LGPOArgs "/parse /u $ContextPath";
        }
        if($Policies0[0]){
            $ParsePolicies = ConvertFrom-LGPOResults -LGPOContents $Policies0[1];
            $CurrentValues += $ParsePolicies;
        }
    }

    Start-RecordAudit -CurrentValues $CurrentValues;
}


Function Remove-GPOsFromLGPO {
    param([array]$Entries,[string]$source)
    $TempDeleteCache = "$current_path\Queue\$source`_delcache.txt"
    $RegistryKeys = @();
    $Removed = 0;
    If(Test-Path $TempDeleteCache){
        Remove-Item $TempDeleteCache;
    }
    ForEach($Entry in $Entries){
        $Collisions = Get-AuditEntries -Key "UID" -Search $UnmarkedEntry.UID
        If($Collisions.Count -eq 0){
            #Need to delete these entries
            $delkey = $Entry.Key;
            $delvaluename = $Entry.ValueName;
            $delcontext = $Entry.Context;
            $DelTemplate = "$delcontext`r`n$delkey`r`n$delvaluename`r`nDELETE`r`n`r`n"
            Add-Content $TempDeleteCache $DelTemplate

            $RegistryKey = Get-RegistryKey -Entry $Entry;
            $RegistryKeys += $RegistryKey;

            $Removed++;
        }
    }
    If(Test-Path $TempDeleteCache){
        Invoke-LGPO -LGPOArgs "/t $TempDeleteCache /v";
        Remove-Item $TempDeleteCache -Force;
    }


}


Function Start-ImportGPOFromLGPO
{
	param(
        [string]$policyFile,
        [switch]$storeResults=$true
    )
    #Format the name of the file
    $ReadFile = [IO.File]::ReadAllText($policyFile);
    If($ReadFile){
        If(!($ReadFile.contains("`s"))){
            $UnencryptedFile = ConvertFrom-EncryptedFile -FileContents $ReadFile;
            if($UnencryptedFile -and $UnencryptedFile -ne "Error"){
                Set-Content -Path $policyFile -Value $UnencryptedFile;
            } else {
                return 0;
            }
        }
    } else {
        return 0;
    }

    $policyFileName = $policyFile.Substring($policyFile.LastIndexOf("\"),
            $policyFile.LastIndexOf(".") - $policyFile.LastIndexOf("\"));
    $pfno = $policyFileName.Substring(1,$policyFileName.Length - 1);

    #Set the location of the error log
    $errorFile = $errorP + "\" + $pfno + "_errorlog" + ".log";
    
    #Set the location of the registry keys for storing the results
    $pfno_REG = "HKLM:\Software\AirWatch\GroupPolicy\$pfno"
    $pfno_SubPath = "Software\AirWatch\GroupPolicy\$pfno";
     
    $StoredData = @{};
    If($storeResults){
       $version = Get-ItemPropertyValueSafe -Path $pfno_Reg -Name "Version" -DefaultValue -1;
       $version++;

       $FileValues = @{"Version"=$version;"FileName"=$pfno}
       $StoredData = Get-AliasMap -FormatedFileName $pfno -FormatedRegistryLocation $pfno_REG -KeyValues $FileValues
    }
   
    #$AuditDB_Main = Open-AuditDatabase;
    $timestamp = (date).ToString("MM-dd-yyyy hh:mm:ss"); 
    

    $Profile = Get-AuditDatabaseContext -Profile "$pfno";
    If(!$Profile){
        $Profile = Add-AuditDatabaseContext -Profile "$pfno";        
    } Else {
        $Current_Entries = $Profile.Entries;
    }

    $LGPO_Import = Invoke-LGPO -LGPOArgs "/t $policyFile /v";
    $LGPO_Record = ConvertFrom-LGPOResults $LGPO_Import;
    
    $ResultsObj = New-Object PSCustomObject -Property @{"New"=0;"Updated"=0;"Removed"=0;"Collisions"=0;"Total"=0}
    $RegistryKeys = @();

    If($Current_Entries){
        $Marked = @();
        ForEach($Entry in $Current_Entries){
            $Exists = $LGPO_Record | Where UID -eq $Entry.UID
            If(($Exists | Measure).Count -eq 1){
                #Existing Entry
                If($Exists.Value -EQ $Entry.Value){
                    #No change
                    $ResultsObj["Collisions"]++;
                } Else {
                    #Record profile change
                    if($Entry.Value -like "*DELETE*"){
                        $ResultsObj.Removed++;
                        $ResultsObj.Total--;
                    } else {
                        $ResultsObj.Changed++;
                        $ResultsObj.Total++;
                    }
                }
            } ElseIf (($Exists | Measure).Count -gt 1){
                #Multiple previous entries 
                
            } Else {
                #New entry
                $ResultsObj.New++;
                $ResultsObj.Total++;
            }
            $RegistryKey = Get-RegistryKey -Entry $Entry;
            $RegistryKeys += $RegistryKey;
            $Marked += $Entry.UID;
        }
        $UnmarkedEntries = $CurrentEntries | where UID -NotIn $Marked;
        
        $Removed = Remove-GPOsFromLGPO -Entries $UnmarkedEntries -Source $pfno
        $ResultsObj.Removed++;
        $ResultsObj.Total--;
    }

    $Profile.Entries = $LGPO_Record;
    Add-AccessPolicy -Name $pfno -RegKeys $RegistryKeys;
    
    $rawDB = ConvertTo-Json -InputObject $AuditDB_Main -Depth 10;
    Set-Content -Path $AuditDatabase -Value $rawDB;    

    if($LGPO_Import){
        return 1;
    } else {
        return 0;
    }
}

function Remove-ManagedGPOs{
    param([string]$ProfileName)    
    if(Test-Path -Path $AuditDatabase){
        $AuditDBJson = [IO.File]::ReadAllText($AuditDatabase);
        $AuditDB_Main = ConvertFrom-JSON -InputObject $AuditDBJson;
    } else{
        return $false;
    }

    $ProfileIndex = ([Collections.Generic.List[Object]]$AuditDB_Main.Profile).FindIndex({$args[0].Name -eq $ProfileName});
    If($ProfileIndex -lt 0){
        return $false;
    }
    $Profile = $AuditDB_Main.Profile | Where Name -EQ $ProfileName;
    
    Remove-GPOsFromLGPO -Entries $Profile.Entries -Source $ProfileName;
    $AuditDB_Main.Profile = $AuditDB_Main.Profile | Where Name -NE $ProfileName;

    $rawDB = ConvertTo-Json -InputObject $AuditDB_Main -Depth 10;
    Set-Content -Path $AuditDatabase -Value $rawDB;  

    return $true;
}

function Invoke-ProcessCommands{
    param([string]$commandfile)
    $ReadFile = [IO.File]::ReadAllText($commandfile);
    If($ReadFile){
        If(!($ReadFile.contains("`s"))){
            $Unencrypted = ConvertFrom-EncryptedFile -FileContents $ReadFile;
            if($Unencrypted -and $Unencrypted -ne "Error"){
               #Do nothing 
            } else {
               return $false;
            }
        } Else {
            $Unencrypted = $ReadFile;
        }
    } 
    $Profiles = ConvertFrom-Json $Unencrypted;
    $ValidProfileStatus = @(3,6);
    $InstalledProfiles = (($Profiles.Profiles | Where Status -NotIn 3,6) | select Id).Id;
    $RemoveProfiles = ($AuditDB_Main.Profile | Select Name) | where {$_.Name -In $InstalledProfiles -and $_.Name -match "[0-9]{1,6}"};

    ForEach($RemoveProfile in $RemoveProfiles.Name){
        Remove-ManagedGPOs -ProfileName $RemoveProfile;
    }
    return $true;
}