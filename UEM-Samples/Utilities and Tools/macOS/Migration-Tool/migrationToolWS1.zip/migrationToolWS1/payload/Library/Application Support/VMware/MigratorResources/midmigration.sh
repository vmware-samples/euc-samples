#!/bin/bash
### Use this script to do any work needed after the previous vendor is removed###
### This script runs after the previous vendor is removed, but before the new enrollment profile is installed ###

DEPNOTIFYLOG="/private/var/tmp/depnotify.log"

echo "Status: Running Mid-Migration script" >> $DEPNOTIFYLOG

exit 0
