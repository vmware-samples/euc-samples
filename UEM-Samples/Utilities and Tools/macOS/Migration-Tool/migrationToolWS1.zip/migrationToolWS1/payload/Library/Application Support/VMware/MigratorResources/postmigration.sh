#!/bin/bash
### Use this script to any migration teardown, such as demoting the user back to Standard. ###
### This script only runs after the new enrollment profile is installed. ###

DEPNOTIFYLOG="/private/var/tmp/depnotify.log"

echo "Status: Running Post-Migration script" >> $DEPNOTIFYLOG

exit 0
