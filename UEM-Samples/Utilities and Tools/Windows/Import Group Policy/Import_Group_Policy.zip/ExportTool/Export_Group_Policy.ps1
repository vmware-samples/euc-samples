

function Migrate-Policies{
	param([string]$FileType,
          [string]$LocalPath,
          [string]$ExportFileName
        )
	if($FileType){ $FileType = 'CSV' }
    if(!$ExportFileName){ 
        $timestamp = Get-Date -format yyyyMMddHHmm;
        $ExportFileName = "exportgpo_" + $timestamp + ".csv";
    }
	
	cd $LocalPath

	Add-Type -Path "..\Includes\PolFileEditor.cs" -ErrorAction Stop

	$HKLMRegistryPath = "$env:systemroot\System32\GroupPolicy\Machine\registry.pol"
	$HKCURegistryPath = "$env:systemroot\System32\GroupPolicy\User\registry.pol"
	 
	$pf = New-Object TJX.PolFileEditor.PolFile 
	$pf.LoadFile($HKLMRegistryPath)
	$entries = $pf.Entries;

    if($entries.Count -gt 0){
        echo "Context,Type,Path,Key,Value" >> $ExportFileName
    }

	$new_line = "";
	foreach($entry in $entries){
		$new_line = "Machine,";
		if($entry["Type"] -eq "REG_DWORD"){
			$new_line = $new_line + "DWord,";
			$new_line = $new_line + $entry.KeyName + "," + $entry.Type + "," + $entry.ValueName + "," + $entry.DWORDValue + "\n";
		} else {
			$new_line = $new_line + "String,";
			$new_line = $new_line + $entry.KeyName+ "," + $entry.Type + "," + $entry.ValueName + "," + $entry.StringValue + "\n";
		}
		echo $new_line >> $ExportFileName
	}
    
    $pf.LoadFile($HKCURegistryPath)
	$entries = $pf.Entries;

	$new_line = "";
	foreach($entry in $entries){
		$new_line = "User,";
		if($entry["Type"] -eq "REG_DWORD"){
			$new_line = $new_line + "DWord,";
			$new_line = $new_line + $entry.KeyName + "," + $entry.Type + "," + $entry.ValueName + "," + $entry.DWORDValue + "\n";
		} else {
			$new_line = $new_line + "String,";
			$new_line = $new_line + $entry.KeyName+ "," + $entry.Type + "," + $entry.ValueName + "," + $entry.StringValue + "\n";
		}
		echo $new_line >> $ExportFileName
	}
    
}

#Test to see if we are in Dev Mode
if($PSScriptRoot -eq ""){
    $current_path = "C:\Temp\grppolicies\ExportTool";
}
else{
    #Only works if running from the file
    $current_path = $PSScriptRoot;
} 

Migrate-Policies -FileType 'CSV' -LocalPath $current_path