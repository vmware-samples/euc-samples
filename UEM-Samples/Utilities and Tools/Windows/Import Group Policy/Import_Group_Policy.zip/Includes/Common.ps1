#requires -Version 2.0

function OpenPolicyFile
{
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string] $Path
    )

    $policyFile = New-Object TJX.PolFileEditor.PolFile
    $policyFile.FileName = $PSCmdlet.GetUnresolvedProviderPathFromPSPath($Path)

    if (Test-Path -LiteralPath $policyFile.FileName)
    {
        try
        {
            $policyFile.LoadFile()
        }
        catch [TJX.PolFileEditor.FileFormatException]
        {
            $message = "File '$Path' is not a valid POL file."
            $exception = New-Object System.Exception($message)

            $errorRecord = New-Object System.Management.Automation.ErrorRecord(
                $exception, 'InvalidPolFileContents', [System.Management.Automation.ErrorCategory]::InvalidData, $Path
            )

            throw $errorRecord
        }
        catch
        {
            $errorRecord = $_
            $message = "Error loading policy file at path '$Path': $($errorRecord.Exception.Message)"
            $exception = New-Object System.Exception($message, $errorRecord.Exception)

            $newErrorRecord = New-Object System.Management.Automation.ErrorRecord(
                $exception, 'FailedToOpenPolicyFile', [System.Management.Automation.ErrorCategory]::OperationStopped, $Path
            )

            throw $newErrorRecord
        }
    }

    return $policyFile
}

function PolEntryToPsObject
{
    param (
        [TJX.PolFileEditor.PolEntry] $PolEntry
    )

    $type = PolEntryTypeToRegistryValueKind $PolEntry.Type
    $data = GetEntryData -Entry $PolEntry -Type $type

    return New-Object psobject -Property @{
        Key       = $PolEntry.KeyName
        ValueName = $PolEntry.ValueName
        Type      = $type
        Data      = $data
    }
}

function GetEntryData
{
    param (
        [TJX.PolFileEditor.PolEntry] $Entry,
        [Microsoft.Win32.RegistryValueKind] $Type
    )

    switch ($type)
    {
        ([Microsoft.Win32.RegistryValueKind]::Binary)
        {
            return $Entry.BinaryValue
        }

        ([Microsoft.Win32.RegistryValueKind]::DWord)
        {
            return $Entry.DWORDValue
        }

        ([Microsoft.Win32.RegistryValueKind]::ExpandString)
        {
            return $Entry.StringValue
        }

        ([Microsoft.Win32.RegistryValueKind]::MultiString)
        {
            return $Entry.MultiStringValue
        }

        ([Microsoft.Win32.RegistryValueKind]::QWord)
        {
            return $Entry.QWORDValue
        }

        ([Microsoft.Win32.RegistryValueKind]::String)
        {
            return $Entry.StringValue
        }
    }

}

function SavePolicyFile
{
    [CmdletBinding(SupportsShouldProcess = $true)]
    param (
        [Parameter(Mandatory = $true)]
        [TJX.PolFileEditor.PolFile] $PolicyFile,

        [switch] $UpdateGptIni
    )

    if ($PSCmdlet.ShouldProcess($PolicyFile.FileName, 'Save new settings'))
    {
        $parentPath = Split-Path $PolicyFile.FileName -Parent
        if (-not (Test-Path -LiteralPath $parentPath -PathType Container))
        {
            try
            {
                $null = New-Item -Path $parentPath -ItemType Directory -ErrorAction Stop -Confirm:$false -WhatIf:$false
            }
            catch
            {
                $errorRecord = $_
                $message = "Error creating parent folder of path '$Path': $($errorRecord.Exception.Message)"
                $exception = New-Object System.Exception($message, $errorRecord.Exception)

                $newErrorRecord = New-Object System.Management.Automation.ErrorRecord(
                    $exception, 'CreateParentFolderError', $errorRecord.CategoryInfo.Category, $Path
                )

                throw $newErrorRecord
            }
        }

        try
        {
            $PolicyFile.SaveFile()
        }
        catch
        {
            $errorRecord = $_
            $message = "Error saving policy file to path '$($PolicyFile.FileName)': $($errorRecord.Exception.Message)"
            $exception = New-Object System.Exception($message, $errorRecord.Exception)

            $newErrorRecord = New-Object System.Management.Automation.ErrorRecord(
                $exception, 'FailedToSavePolicyFile', [System.Management.Automation.ErrorCategory]::OperationStopped, $PolicyFile
            )

            throw $newErrorRecord
        }
    }

    if ($UpdateGptIni)
    {
        if ($policyFile.FileName -match '^(.*)\\+([^\\]+)\\+[^\\]+$' -and
            $Matches[2] -eq 'User' -or $Matches[2] -eq 'Machine')
        {
            $iniPath = Join-Path $Matches[1] GPT.ini

            if (Test-Path -LiteralPath $iniPath -PathType Leaf)
            {
                if ($PSCmdlet.ShouldProcess($iniPath, 'Increment version number in INI file'))
                {
                    IncrementGptIniVersion -Path $iniPath -PolicyType $Matches[2] -Confirm:$false -WhatIf:$false
                }
            }
            else
            {
                if ($PSCmdlet.ShouldProcess($iniPath, 'Create new gpt.ini file'))
                {
                    NewGptIni -Path $iniPath -PolicyType $Matches[2]
                }
            }
        }
    }
}

function NewGptIni
{
    param (
        [string] $Path,
        [string[]] $PolicyType
    )

    $parent = Split-Path $Path -Parent

    if (-not (Test-Path $parent -PathType Container))
    {
        $null = New-Item -Path $parent -ItemType Directory -ErrorAction Stop
    }

    $version = GetNewVersionNumber -Version 0 -PolicyType $PolicyType

    Set-Content -Path $Path -Encoding Ascii -Value @"
[General]
gPCMachineExtensionNames=[{35378EAC-683F-11D2-A89A-00C04FBBCFA2}{D02B1F72-3407-48AE-BA88-E8213C6761F1}]
Version=$version
gPCUserExtensionNames=[{35378EAC-683F-11D2-A89A-00C04FBBCFA2}{D02B1F72-3407-48AE-BA88-E8213C6761F1}]
"@
}

function IncrementGptIniVersion
{
    [CmdletBinding(SupportsShouldProcess = $true)]
    param (
        [string] $Path,
        [string[]] $PolicyType
    )

    $foundVersionLine = $false
    $section = ''

    $newContents = @(
        foreach ($line in Get-Content $Path)
        {
            # This might not be the most unreadable regex ever, but it's trying hard to be!
            # It's looking for section lines:  [SectionName]
            if ($line -match '^\s*\[([^\]]+)\]\s*$')
            {
                if ($section -eq 'General')
                {
                    if (-not $foundVersionLine)
                    {
                        $foundVersionLine = $true
                        $newVersion = GetNewVersionNumber -Version 0 -PolicyType $PolicyType

                        "Version=$newVersion"
                    }

                    if (-not $foundMachineExtensionLine)
                    {
                        $foundMachineExtensionLine = $true
                        'gPCMachineExtensionNames=[{35378EAC-683F-11D2-A89A-00C04FBBCFA2}{D02B1F72-3407-48AE-BA88-E8213C6761F1}]'
                    }

                    if (-not $foundUserExtensionLine)
                    {
                        $foundUserExtensionLine = $true
                        'gPCUserExtensionNames=[{35378EAC-683F-11D2-A89A-00C04FBBCFA2}{D02B1F73-3407-48AE-BA88-E8213C6761F1}]'
                    }
                }

                $section = $matches[1]
            }
            elseif ($section -eq 'General' -and
                    $line -match '^\s*Version\s*=\s*(\d+)\s*$' -and
                    $null -ne ($version = $matches[1] -as [uint32]))
            {
                $foundVersionLine = $true
                $newVersion = GetNewVersionNumber -Version $version -PolicyType $PolicyType
                $line = "Version=$newVersion"
            }
            elseif ($section -eq 'General' -and $line -match '^\s*gPC(Machine|User)ExtensionNames\s*=')
            {
                if ($matches[1] -eq 'Machine')
                {
                    $foundMachineExtensionLine = $true
                }
                else
                {
                    $foundUserExtensionLine = $true
                }

                $line = EnsureAdminTemplateCseGuidsArePresent $line
            }

            $line
        }

        if ($section -eq 'General')
        {
            if (-not $foundVersionLine)
            {
                $foundVersionLine = $true
                $newVersion = GetNewVersionNumber -Version 0 -PolicyType $PolicyType

                "Version=$newVersion"
            }

            if (-not $foundMachineExtensionLine)
            {
                $foundMachineExtensionLine = $true
                'gPCMachineExtensionNames=[{35378EAC-683F-11D2-A89A-00C04FBBCFA2}{D02B1F72-3407-48AE-BA88-E8213C6761F1}]'
            }

            if (-not $foundUserExtensionLine)
            {
                $foundUserExtensionLine = $true
                'gPCUserExtensionNames=[{35378EAC-683F-11D2-A89A-00C04FBBCFA2}{D02B1F73-3407-48AE-BA88-E8213C6761F1}]'
            }
        }
    )

    if ($PSCmdlet.ShouldProcess($Path, 'Increment Version number'))
    {
        Set-Content -Path $Path -Value $newContents -Encoding Ascii -Confirm:$false -WhatIf:$false
    }
}

function EnsureAdminTemplateCseGuidsArePresent
{
    param ([string] $Line)

    # These lines contain lists of GUIDs in "registry" format (with the curly braces), separated by nothing, wrapped in a pair of square brackets.  Ex:
    # gPCMachineExtensionNames=[{35378EAC-683F-11D2-A89A-00C04FBBCFA2}{D02B1F72-3407-48AE-BA88-E8213C6761F1}]

    # Per Darren Mar-Elia, these GUIDs must be in alphabetical order, or GP processing will have problems.

    if ($Line -notmatch '\s*(gPC(?:Machine|User)ExtensionNames)\s*=\s*\[([^\]]*)\]\s*$')
    {
        throw "Malformed gpt.ini line: $Line"
    }

    $valueName = $matches[1]
    $guidStrings = @($matches[2] -split '(?<=})(?={)')

    $guidList = @(
        $guidStrings
        '{35378EAC-683F-11D2-A89A-00C04FBBCFA2}'
        '{D02B1F72-3407-48AE-BA88-E8213C6761F1}'
    )

    $newGuidString = ($guidList | Sort-Object -Unique) -join ''

    return "$valueName=[$newGuidString]"
}

function GetNewVersionNumber
{
    param (
        [UInt32] $Version,
        [string[]] $PolicyType
    )

    # User version is the high 16 bits, Machine version is the low 16 bits.
    # Reference:  http://blogs.technet.com/b/grouppolicy/archive/2007/12/14/understanding-the-gpo-version-number.aspx

    $pair = UInt32ToUInt16Pair -UInt32 $version

    if ($PolicyType -contains 'User')
    {
        $pair.HighPart++
    }

    if ($PolicyType -contains 'Machine')
    {
        $pair.LowPart++
    }

    return UInt16PairToUInt32 -UInt16Pair $pair
}

function UInt32ToUInt16Pair
{
    param ([UInt32] $UInt32)

    # Deliberately avoiding bitwise shift operators here, for PowerShell v2 compatibility.

    $lowPart  = $UInt32 -band 0xFFFF
    $highPart = ($UInt32 - $lowPart) / 0x10000

    return New-Object psobject -Property @{
        LowPart  = [UInt16] $lowPart
        HighPart = [UInt16] $highPart
    }
}

function UInt16PairToUInt32
{
    param ([object] $UInt16Pair)

    # Deliberately avoiding bitwise shift operators here, for PowerShell v2 compatibility.

    return ([UInt32] $UInt16Pair.HighPart) * 0x10000 + $UInt16Pair.LowPart
}

function PolEntryTypeToRegistryValueKind
{
    param ([TJX.PolFileEditor.PolEntryType] $PolEntryType)

    switch ($PolEntryType)
    {
        ([TJX.PolFileEditor.PolEntryType]::REG_NONE)
        {
            return [Microsoft.Win32.RegistryValueKind]::None
        }

        ([TJX.PolFileEditor.PolEntryType]::REG_DWORD)
        {
            return [Microsoft.Win32.RegistryValueKind]::DWord
        }

        ([TJX.PolFileEditor.PolEntryType]::REG_DWORD_BIG_ENDIAN)
        {
            return [Microsoft.Win32.RegistryValueKind]::DWord
        }

        ([TJX.PolFileEditor.PolEntryType]::REG_BINARY)
        {
            return [Microsoft.Win32.RegistryValueKind]::Binary
        }

        ([TJX.PolFileEditor.PolEntryType]::REG_EXPAND_SZ)
        {
            return [Microsoft.Win32.RegistryValueKind]::ExpandString
        }

        ([TJX.PolFileEditor.PolEntryType]::REG_MULTI_SZ)
        {
            return [Microsoft.Win32.RegistryValueKind]::MultiString
        }

        ([TJX.PolFileEditor.PolEntryType]::REG_QWORD)
        {
            return [Microsoft.Win32.RegistryValueKind]::QWord
        }

        ([TJX.PolFileEditor.PolEntryType]::REG_SZ)
        {
            return [Microsoft.Win32.RegistryValueKind]::String
        }
    }
}

function GetPolFilePath
{
    param (
        [Parameter(Mandatory = $true, ParameterSetName = 'PolicyType')]
        [string] $PolicyType,

        [Parameter(Mandatory = $true, ParameterSetName = 'Account')]
        [string] $Account
    )

    if ($PolicyType)
    {
        switch ($PolicyType)
        {
            'Machine'
            {
                return Join-Path $env:SystemRoot System32\GroupPolicy\Machine\registry.pol
            }

            'User'
            {
                return Join-Path $env:SystemRoot System32\GroupPolicy\User\registry.pol
            }

            'Administrators'
            {
                # BUILTIN\Administrators well-known SID
                return Join-Path $env:SystemRoot System32\GroupPolicyUsers\S-1-5-32-544\User\registry.pol
            }

            'NonAdministrators'
            {
                # BUILTIN\Users well-known SID
                return Join-Path $env:SystemRoot System32\GroupPolicyUsers\S-1-5-32-545\User\registry.pol
            }
        }
    }
    else
    {
        try
        {
            $sid = $Account -as [System.Security.Principal.SecurityIdentifier]

            if ($null -eq $sid)
            {
                $sid = GetSidForAccount $Account
            }

            return Join-Path $env:SystemRoot "System32\GroupPolicyUsers\$($sid.Value)\User\registry.pol"
        }
        catch
        {
            throw
        }
    }
}

function GetSidForAccount($Account)
{
    $acc = $Account
    if ($acc -notlike '*\*') { $acc = "$env:COMPUTERNAME\$acc" }

    try
    {
        $ntAccount = [System.Security.Principal.NTAccount]$acc
        return $ntAccount.Translate([System.Security.Principal.SecurityIdentifier])
    }
    catch
    {
        $message = "Could not translate account '$acc' to a security identifier."
        $exception = New-Object System.Exception($message, $_.Exception)
        $errorRecord = New-Object System.Management.Automation.ErrorRecord(
            $exception,
            'CouldNotGetSidForAccount',
            [System.Management.Automation.ErrorCategory]::ObjectNotFound,
            $Acc
        )

        throw $errorRecord
    }
}

function DataIsEqual
{
    param (
        [object] $First,
        [object] $Second,
        [Microsoft.Win32.RegistryValueKind] $Type
    )

    if ($Type -eq [Microsoft.Win32.RegistryValueKind]::String -or
        $Type -eq [Microsoft.Win32.RegistryValueKind]::ExpandString -or
        $Type -eq [Microsoft.Win32.RegistryValueKind]::DWord -or
        $Type -eq [Microsoft.Win32.RegistryValueKind]::QWord)
    {
        return @($First)[0] -ceq @($Second)[0]
    }

    # If we get here, $Type is either MultiString or Binary, both of which need to compare arrays.
    # The PolicyFileEditor module never returns type Unknown or None.

    $First = @($First)
    $Second = @($Second)

    if ($First.Count -ne $Second.Count) { return $false }

    $count = $First.Count
    for ($i = 0; $i -lt $count; $i++)
    {
        if ($First[$i] -cne $Second[$i]) { return $false }
    }

    return $true
}

function ParseKeyValueName
{
    param ([string] $KeyValueName)

    if ($KeyValueName.EndsWith('\'))
    {
        $key       = $KeyValueName -replace '\\$'
        $valueName = ''
    }
    else
    {
        $key       = Split-Path $KeyValueName -Parent
        $valueName = Split-Path $KeyValueName -Leaf
    }

    return $key, $valueName
}

function GetTargetResourceCommon
{
    param (
        [string] $Path,
        [string] $KeyValueName
    )

    $configuration = @{
        PolicyType   = $PolicyType
        KeyValueName = $KeyValueName
        Ensure       = 'Absent'
        Data         = $null
        Type         = [Microsoft.Win32.RegistryValueKind]::Unknown
    }

    if (Test-Path -LiteralPath $path -PathType Leaf)
    {
        $key, $valueName = ParseKeyValueName $KeyValueName
        $entry = Get-PolicyFileEntry -Path $Path -Key $key -ValueName $valueName

        if ($entry)
        {
            $configuration['Ensure'] = 'Present'
            $configuration['Type']   = $entry.Type
            $configuration['Data']   = $entry.Data
        }
    }

    return $configuration
}

function SetTargetResourceCommon
{
    param (
        [string] $Path,
        [string] $KeyValueName,
        [string] $Ensure,
        [string[]] $Data,
        [Microsoft.Win32.RegistryValueKind] $Type
    )

    if ($null -eq $Data) { $Data = @() }

    try
    {
        Assert-ValidDataAndType -Data $Data -Type $Type
    }
    catch
    {
        Write-Error -ErrorRecord $_
        return
    }

    $key, $valueName = ParseKeyValueName $KeyValueName

    if ($Ensure -eq 'Present')
    {
        Set-PolicyFileEntry -Path $Path -Key $key -ValueName $valueName -Data $Data -Type $Type
    }
    else
    {
        Remove-PolicyFileEntry -Path $Path -Key $key -ValueName $valueName
    }
}

function TestTargetResourceCommon
{
    [OutputType([bool])]
    param (
        [string] $Path,
        [string] $KeyValueName,
        [string] $Ensure,
        [string[]] $Data,
        [Microsoft.Win32.RegistryValueKind] $Type
    )

    if ($null -eq $Data) { $Data = @() }

    try
    {
        Assert-ValidDataAndType -Data $Data -Type $Type
    }
    catch
    {
        Write-Error -ErrorRecord $_
        return $false
    }

    $key, $valueName = ParseKeyValueName $KeyValueName

    $fileExists = Test-Path -LiteralPath $Path -PathType Leaf

    if ($Ensure -eq 'Present')
    {
        if (-not $fileExists) { return $false }
        $entry = Get-PolicyFileEntry -Path $Path -Key $key -ValueName $valueName

        return $null -ne $entry -and $Type -eq $entry.Type -and (DataIsEqual $entry.Data $Data -Type $Type)
    }
    else # Ensure is 'Absent'
    {
        if (-not $fileExists) { return $true }
        $entry = Get-PolicyFileEntry -Path $Path -Key $key -ValueName $valueName

        return $null -eq $entry
    }

}

function Assert-ValidDataAndType
{
    param (
        [string[]] $Data,
        [Microsoft.Win32.RegistryValueKind] $Type
    )

    if ($Type -ne [Microsoft.Win32.RegistryValueKind]::MultiString -and
        $Type -ne [Microsoft.Win32.RegistryValueKind]::Binary -and
        $Data.Count -gt 1)
    {
        $errorRecord = InvalidDataTypeCombinationErrorRecord -Message 'Do not pass arrays with multiple values to the -Data parameter when -Type is not set to either Binary or MultiString.'
        throw $errorRecord
    }
}

function InvalidDataTypeCombinationErrorRecord($Message)
{
    $exception = New-Object System.Exception($Message)
    return New-Object System.Management.Automation.ErrorRecord(
        $exception, 'InvalidDataTypeCombination', [System.Management.Automation.ErrorCategory]::InvalidArgument, $null
    )
}

# SIG # Begin signature block
# MIIgHQYJKoZIhvcNAQcCoIIgDjCCIAoCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUGRemC/nZQa2rlynJDFwOzq3g
# oSygghtMMIIDtzCCAp+gAwIBAgIQDOfg5RfYRv6P5WD8G/AwOTANBgkqhkiG9w0B
# AQUFADBlMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYD
# VQQLExB3d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdpQ2VydCBBc3N1cmVk
# IElEIFJvb3QgQ0EwHhcNMDYxMTEwMDAwMDAwWhcNMzExMTEwMDAwMDAwWjBlMQsw
# CQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cu
# ZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdpQ2VydCBBc3N1cmVkIElEIFJvb3Qg
# Q0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCtDhXO5EOAXLGH87dg
# +XESpa7cJpSIqvTO9SA5KFhgDPiA2qkVlTJhPLWxKISKityfCgyDF3qPkKyK53lT
# XDGEKvYPmDI2dsze3Tyoou9q+yHyUmHfnyDXH+Kx2f4YZNISW1/5WBg1vEfNoTb5
# a3/UsDg+wRvDjDPZ2C8Y/igPs6eD1sNuRMBhNZYW/lmci3Zt1/GiSw0r/wty2p5g
# 0I6QNcZ4VYcgoc/lbQrISXwxmDNsIumH0DJaoroTghHtORedmTpyoeb6pNnVFzF1
# roV9Iq4/AUaG9ih5yLHa5FcXxH4cDrC0kqZWs72yl+2qp/C3xag/lRbQ/6GW6whf
# GHdPAgMBAAGjYzBhMA4GA1UdDwEB/wQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB0G
# A1UdDgQWBBRF66Kv9JLLgjEtUYunpyGd823IDzAfBgNVHSMEGDAWgBRF66Kv9JLL
# gjEtUYunpyGd823IDzANBgkqhkiG9w0BAQUFAAOCAQEAog683+Lt8ONyc3pklL/3
# cmbYMuRCdWKuh+vy1dneVrOfzM4UKLkNl2BcEkxY5NM9g0lFWJc1aRqoR+pWxnmr
# EthngYTffwk8lOa4JiwgvT2zKIn3X/8i4peEH+ll74fg38FnSbNd67IJKusm7Xi+
# fT8r87cmNW1fiQG2SVufAQWbqz0lwcy2f8Lxb4bG+mRo64EtlOtCt/qMHt1i8b5Q
# Z7dsvfPxH2sMNgcWfzd8qVttevESRmCD1ycEvkvOl77DZypoEd+A5wwzZr8TDRRu
# 838fYxAe+o0bJW1sj6W3YQGx0qMmoRBxna3iw/nDmVG3KwcIzi7mULKn+gpFL6Lw
# 8jCCBRowggQCoAMCAQICEARpjsgwUFECipkHfBug8q4wDQYJKoZIhvcNAQELBQAw
# cjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQ
# d3d3LmRpZ2ljZXJ0LmNvbTExMC8GA1UEAxMoRGlnaUNlcnQgU0hBMiBBc3N1cmVk
# IElEIENvZGUgU2lnbmluZyBDQTAeFw0xNTA0MDEwMDAwMDBaFw0xNjA2MTYxMjAw
# MDBaMGExCzAJBgNVBAYTAkNBMQswCQYDVQQIEwJPTjERMA8GA1UEBxMIQnJhbXB0
# b24xGDAWBgNVBAoTD0RhdmlkIExlZSBXeWF0dDEYMBYGA1UEAxMPRGF2aWQgTGVl
# IFd5YXR0MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAxJFq4k/bTtmT
# A7Y1/bQj6FARpMLoVMi7eOWm/Vk1+TsjuWJu4/kjGsvjUq36ZLrnUCkT3btkgIpj
# TUxYjUoa6h3i7OZnVgJQPQ3Cn3E/+WSHxnMFBwXe4mo6QXT68Ite/D3041/XXAph
# ApJLJ14otfoC+I9Fht/GzB0uUJyArYUs3M1f4iKP1kcfWw7+52FDHBy/Nx2Bi8h4
# mlPYmtbzdJS0arzP9WDKw8oqcOna4AyR5qdEjZjavuKl02bLxdm7laQp++2r9e49
# N/DDPf5mgm8/CqcU+laBXaftTboHk/vNCNOeFwBtJtQ9Yg4aOxkEUg7L87JNM9Uj
# DjoHOc5O7QIDAQABo4IBuzCCAbcwHwYDVR0jBBgwFoAUWsS5eyoKo6XqcQPAYPkt
# 9mV1DlgwHQYDVR0OBBYEFD7qfa8Cv5TGKB+UG9Ih5Vf7a78UMA4GA1UdDwEB/wQE
# AwIHgDATBgNVHSUEDDAKBggrBgEFBQcDAzB3BgNVHR8EcDBuMDWgM6Axhi9odHRw
# Oi8vY3JsMy5kaWdpY2VydC5jb20vc2hhMi1hc3N1cmVkLWNzLWcxLmNybDA1oDOg
# MYYvaHR0cDovL2NybDQuZGlnaWNlcnQuY29tL3NoYTItYXNzdXJlZC1jcy1nMS5j
# cmwwQgYDVR0gBDswOTA3BglghkgBhv1sAwEwKjAoBggrBgEFBQcCARYcaHR0cHM6
# Ly93d3cuZGlnaWNlcnQuY29tL0NQUzCBhAYIKwYBBQUHAQEEeDB2MCQGCCsGAQUF
# BzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wTgYIKwYBBQUHMAKGQmh0dHA6
# Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFNIQTJBc3N1cmVkSURDb2Rl
# U2lnbmluZ0NBLmNydDAMBgNVHRMBAf8EAjAAMA0GCSqGSIb3DQEBCwUAA4IBAQDf
# PrccGNpJ3mi1dR/3Tl+M/+tbHQKP9q+RICPCwMSC53zqbFoOc1bkEGi6JzrrPkvz
# M+fkF6Y9mOICeOeow4/Ny5tn0VlASwz0YCSVdHi2ynKZrrz/wGTB3Mnpg0Fx/boq
# bUTiAeE25+9o1um6y6tnHyT95Bp0ZfX/wnVwklSZ01fgidyqZHrnWkFg13iG8Tdy
# pfgk1ZOysLfVlepnSY1LF0xvBop1y6FDlNU1irow9+Ed0Fgeh49Ex0UrWVyCYhJZ
# RcYIvqYH8ZWbNc6gLY8Bex4KlBJlDmGmBa2aLg0yZG3+i7gZ0amaa17o+BdOAcRH
# B+ZDnGGSSJpl+AXTIhXKMIIFMDCCBBigAwIBAgIQBAkYG1/Vu2Z1U0O1b5VQCDAN
# BgkqhkiG9w0BAQsFADBlMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQg
# SW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdpQ2Vy
# dCBBc3N1cmVkIElEIFJvb3QgQ0EwHhcNMTMxMDIyMTIwMDAwWhcNMjgxMDIyMTIw
# MDAwWjByMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYD
# VQQLExB3d3cuZGlnaWNlcnQuY29tMTEwLwYDVQQDEyhEaWdpQ2VydCBTSEEyIEFz
# c3VyZWQgSUQgQ29kZSBTaWduaW5nIENBMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8A
# MIIBCgKCAQEA+NOzHH8OEa9ndwfTCzFJGc/Q+0WZsTrbRPV/5aid2zLXcep2nQUu
# t4/6kkPApfmJ1DcZ17aq8JyGpdglrA55KDp+6dFn08b7KSfH03sjlOSRI5aQd4L5
# oYQjZhJUM1B0sSgmuyRpwsJS8hRniolF1C2ho+mILCCVrhxKhwjfDPXiTWAYvqrE
# sq5wMWYzcT6scKKrzn/pfMuSoeU7MRzP6vIK5Fe7SrXpdOYr/mzLfnQ5Ng2Q7+S1
# TqSp6moKq4TzrGdOtcT3jNEgJSPrCGQ+UpbB8g8S9MWOD8Gi6CxR93O8vYWxYoNz
# QYIH5DiLanMg0A9kczyen6Yzqf0Z3yWT0QIDAQABo4IBzTCCAckwEgYDVR0TAQH/
# BAgwBgEB/wIBADAOBgNVHQ8BAf8EBAMCAYYwEwYDVR0lBAwwCgYIKwYBBQUHAwMw
# eQYIKwYBBQUHAQEEbTBrMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2Vy
# dC5jb20wQwYIKwYBBQUHMAKGN2h0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9E
# aWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcnQwgYEGA1UdHwR6MHgwOqA4oDaGNGh0
# dHA6Ly9jcmw0LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5j
# cmwwOqA4oDaGNGh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3Vy
# ZWRJRFJvb3RDQS5jcmwwTwYDVR0gBEgwRjA4BgpghkgBhv1sAAIEMCowKAYIKwYB
# BQUHAgEWHGh0dHBzOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwCgYIYIZIAYb9bAMw
# HQYDVR0OBBYEFFrEuXsqCqOl6nEDwGD5LfZldQ5YMB8GA1UdIwQYMBaAFEXroq/0
# ksuCMS1Ri6enIZ3zbcgPMA0GCSqGSIb3DQEBCwUAA4IBAQA+7A1aJLPzItEVyCx8
# JSl2qB1dHC06GsTvMGHXfgtg/cM9D8Svi/3vKt8gVTew4fbRknUPUbRupY5a4l4k
# gU4QpO4/cY5jDhNLrddfRHnzNhQGivecRk5c/5CxGwcOkRX7uq+1UcKNJK4kxscn
# KqEpKBo6cSgCPC6Ro8AlEeKcFEehemhor5unXCBc2XGxDI+7qPjFEmifz0DLQESl
# E/DmZAwlCEIysjaKJAL+L3J+HNdJRZboWR3p+nRka7LrZkPas7CM1ekN3fYBIM6Z
# MWM9CBoYs4GbT8aTEAb8B4H6i9r5gkn3Ym6hU/oSlBiFLpKR6mhsRDKyZqHnGKSa
# ZFHvMIIGajCCBVKgAwIBAgIQAwGaAjr/WLFr1tXq5hfwZjANBgkqhkiG9w0BAQUF
# ADBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQL
# ExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQDExhEaWdpQ2VydCBBc3N1cmVkIElE
# IENBLTEwHhcNMTQxMDIyMDAwMDAwWhcNMjQxMDIyMDAwMDAwWjBHMQswCQYDVQQG
# EwJVUzERMA8GA1UEChMIRGlnaUNlcnQxJTAjBgNVBAMTHERpZ2lDZXJ0IFRpbWVz
# dGFtcCBSZXNwb25kZXIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCj
# ZF38fLPggjXg4PbGKuZJdTvMbuBTqZ8fZFnmfGt/a4ydVfiS457VWmNbAklQ2YPO
# b2bu3cuF6V+l+dSHdIhEOxnJ5fWRn8YUOawk6qhLLJGJzF4o9GS2ULf1ErNzlgpn
# o75hn67z/RJ4dQ6mWxT9RSOOhkRVfRiGBYxVh3lIRvfKDo2n3k5f4qi2LVkCYYhh
# chhoubh87ubnNC8xd4EwH7s2AY3vJ+P3mvBMMWSN4+v6GYeofs/sjAw2W3rBerh4
# x8kGLkYQyI3oBGDbvHN0+k7Y/qpA8bLOcEaD6dpAoVk62RUJV5lWMJPzyWHM0AjM
# a+xiQpGsAsDvpPCJEY93AgMBAAGjggM1MIIDMTAOBgNVHQ8BAf8EBAMCB4AwDAYD
# VR0TAQH/BAIwADAWBgNVHSUBAf8EDDAKBggrBgEFBQcDCDCCAb8GA1UdIASCAbYw
# ggGyMIIBoQYJYIZIAYb9bAcBMIIBkjAoBggrBgEFBQcCARYcaHR0cHM6Ly93d3cu
# ZGlnaWNlcnQuY29tL0NQUzCCAWQGCCsGAQUFBwICMIIBVh6CAVIAQQBuAHkAIAB1
# AHMAZQAgAG8AZgAgAHQAaABpAHMAIABDAGUAcgB0AGkAZgBpAGMAYQB0AGUAIABj
# AG8AbgBzAHQAaQB0AHUAdABlAHMAIABhAGMAYwBlAHAAdABhAG4AYwBlACAAbwBm
# ACAAdABoAGUAIABEAGkAZwBpAEMAZQByAHQAIABDAFAALwBDAFAAUwAgAGEAbgBk
# ACAAdABoAGUAIABSAGUAbAB5AGkAbgBnACAAUABhAHIAdAB5ACAAQQBnAHIAZQBl
# AG0AZQBuAHQAIAB3AGgAaQBjAGgAIABsAGkAbQBpAHQAIABsAGkAYQBiAGkAbABp
# AHQAeQAgAGEAbgBkACAAYQByAGUAIABpAG4AYwBvAHIAcABvAHIAYQB0AGUAZAAg
# AGgAZQByAGUAaQBuACAAYgB5ACAAcgBlAGYAZQByAGUAbgBjAGUALjALBglghkgB
# hv1sAxUwHwYDVR0jBBgwFoAUFQASKxOYspkH7R7for5XDStnAs0wHQYDVR0OBBYE
# FGFaTSS2STKdSip5GoNL9B6Jwcp9MH0GA1UdHwR2MHQwOKA2oDSGMmh0dHA6Ly9j
# cmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRENBLTEuY3JsMDigNqA0
# hjJodHRwOi8vY3JsNC5kaWdpY2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURDQS0x
# LmNybDB3BggrBgEFBQcBAQRrMGkwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRp
# Z2ljZXJ0LmNvbTBBBggrBgEFBQcwAoY1aHR0cDovL2NhY2VydHMuZGlnaWNlcnQu
# Y29tL0RpZ2lDZXJ0QXNzdXJlZElEQ0EtMS5jcnQwDQYJKoZIhvcNAQEFBQADggEB
# AJ0lfhszTbImgVybhs4jIA+Ah+WI//+x1GosMe06FxlxF82pG7xaFjkAneNshORa
# QPveBgGMN/qbsZ0kfv4gpFetW7easGAm6mlXIV00Lx9xsIOUGQVrNZAQoHuXx/Y/
# 5+IRQaa9YtnwJz04HShvOlIJ8OxwYtNiS7Dgc6aSwNOOMdgv420XEwbu5AO2FKvz
# j0OncZ0h3RTKFV2SQdr5D4HRmXQNJsQOfxu19aDxxncGKBXp2JPlVRbwuwqrHNtc
# SCdmyKOLChzlldquxC5ZoGHd2vNtomHpigtt7BIYvfdVVEADkitrwlHCCkivsNRu
# 4PQUCjob4489yq9qjXvc2EQwggbNMIIFtaADAgECAhAG/fkDlgOt6gAK6z8nu7ob
# MA0GCSqGSIb3DQEBBQUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2Vy
# dCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNVBAMTG0RpZ2lD
# ZXJ0IEFzc3VyZWQgSUQgUm9vdCBDQTAeFw0wNjExMTAwMDAwMDBaFw0yMTExMTAw
# MDAwMDBaMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAX
# BgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IEFzc3Vy
# ZWQgSUQgQ0EtMTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAOiCLZn5
# ysJClaWAc0Bw0p5WVFypxNJBBo/JM/xNRZFcgZ/tLJz4FlnfnrUkFcKYubR3SdyJ
# xArar8tea+2tsHEx6886QAxGTZPsi3o2CAOrDDT+GEmC/sfHMUiAfB6iD5IOUMnG
# h+s2P9gww/+m9/uizW9zI/6sVgWQ8DIhFonGcIj5BZd9o8dD3QLoOz3tsUGj7T++
# 25VIxO4es/K8DCuZ0MZdEkKB4YNugnM/JksUkK5ZZgrEjb7SzgaurYRvSISbT0C5
# 8Uzyr5j79s5AXVz2qPEvr+yJIvJrGGWxwXOt1/HYzx4KdFxCuGh+t9V3CidWfA9i
# pD8yFGCV/QcEogkCAwEAAaOCA3owggN2MA4GA1UdDwEB/wQEAwIBhjA7BgNVHSUE
# NDAyBggrBgEFBQcDAQYIKwYBBQUHAwIGCCsGAQUFBwMDBggrBgEFBQcDBAYIKwYB
# BQUHAwgwggHSBgNVHSAEggHJMIIBxTCCAbQGCmCGSAGG/WwAAQQwggGkMDoGCCsG
# AQUFBwIBFi5odHRwOi8vd3d3LmRpZ2ljZXJ0LmNvbS9zc2wtY3BzLXJlcG9zaXRv
# cnkuaHRtMIIBZAYIKwYBBQUHAgIwggFWHoIBUgBBAG4AeQAgAHUAcwBlACAAbwBm
# ACAAdABoAGkAcwAgAEMAZQByAHQAaQBmAGkAYwBhAHQAZQAgAGMAbwBuAHMAdABp
# AHQAdQB0AGUAcwAgAGEAYwBjAGUAcAB0AGEAbgBjAGUAIABvAGYAIAB0AGgAZQAg
# AEQAaQBnAGkAQwBlAHIAdAAgAEMAUAAvAEMAUABTACAAYQBuAGQAIAB0AGgAZQAg
# AFIAZQBsAHkAaQBuAGcAIABQAGEAcgB0AHkAIABBAGcAcgBlAGUAbQBlAG4AdAAg
# AHcAaABpAGMAaAAgAGwAaQBtAGkAdAAgAGwAaQBhAGIAaQBsAGkAdAB5ACAAYQBu
# AGQAIABhAHIAZQAgAGkAbgBjAG8AcgBwAG8AcgBhAHQAZQBkACAAaABlAHIAZQBp
# AG4AIABiAHkAIAByAGUAZgBlAHIAZQBuAGMAZQAuMAsGCWCGSAGG/WwDFTASBgNV
# HRMBAf8ECDAGAQH/AgEAMHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0
# cDovL29jc3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0
# cy5kaWdpY2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3J0MIGBBgNV
# HR8EejB4MDqgOKA2hjRodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRB
# c3N1cmVkSURSb290Q0EuY3JsMDqgOKA2hjRodHRwOi8vY3JsNC5kaWdpY2VydC5j
# b20vRGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3JsMB0GA1UdDgQWBBQVABIrE5iy
# mQftHt+ivlcNK2cCzTAfBgNVHSMEGDAWgBRF66Kv9JLLgjEtUYunpyGd823IDzAN
# BgkqhkiG9w0BAQUFAAOCAQEARlA+ybcoJKc4HbZbKa9Sz1LpMUerVlx71Q0LQbPv
# 7HUfdDjyslxhopyVw1Dkgrkj0bo6hnKtOHisdV0XFzRyR4WUVtHruzaEd8wkpfME
# GVWp5+Pnq2LN+4stkMLA0rWUvV5PsQXSDj0aqRRbpoYxYqioM+SbOafE9c4deHaU
# JXPkKqvPnHZL7V/CSxbkS3BMAIke/MV5vEwSV/5f4R68Al2o/vsHOE8Nxl2RuQ9n
# Rc3Wg+3nkg2NsWmMT/tZ4CMP0qquAHzunEIOz5HXJ7cW7g/DvXwKoO4sCFWFIrjr
# GBpN/CohrUkxg0eVd3HcsRtLSxwQnHcUwZ1PL1qVCCkQJjGCBDswggQ3AgEBMIGG
# MHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsT
# EHd3dy5kaWdpY2VydC5jb20xMTAvBgNVBAMTKERpZ2lDZXJ0IFNIQTIgQXNzdXJl
# ZCBJRCBDb2RlIFNpZ25pbmcgQ0ECEARpjsgwUFECipkHfBug8q4wCQYFKw4DAhoF
# AKB4MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisG
# AQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcN
# AQkEMRYEFBTmmvJ7/MQB0Qht/e1jK+01M5fhMA0GCSqGSIb3DQEBAQUABIIBAG+7
# ZJEcU+89Qv/2fq4dRCrz2vkY/XTzkY9WBcgG9DBs9r6DueGQr270FpZy9OQQiuRO
# iEJlYxhxRLC8o7jKLUcpYvIdMjlU352jmhgSWYhd0COL9a5dhvl5V24kexS9+D9Y
# AkbvslEyIb76zK4fcww2wJk/CC2OgeI5Z0vDp0d10ptiyc5cKbsOy7dyYf5bhqax
# /mi+YNxeFR5fpjjwp0TZvnNPoBZO97YkzYwHHaF6FjufbWtBX4Foxxdaq5/t3ebT
# LSfw230TpaJ8nVZ7Q98+273jwl/OprI4DJcjRWYRulwg2nDtQKEe9TJ+nd80BTGj
# DB1IIpXY38S4kBgdGF6hggIPMIICCwYJKoZIhvcNAQkGMYIB/DCCAfgCAQEwdjBi
# MQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3
# d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQDExhEaWdpQ2VydCBBc3N1cmVkIElEIENB
# LTECEAMBmgI6/1ixa9bV6uYX8GYwCQYFKw4DAhoFAKBdMBgGCSqGSIb3DQEJAzEL
# BgkqhkiG9w0BBwEwHAYJKoZIhvcNAQkFMQ8XDTE1MDQwNTE2NDkyNVowIwYJKoZI
# hvcNAQkEMRYEFB2JTFxSE+72IxUQYH7/rqMBsYVbMA0GCSqGSIb3DQEBAQUABIIB
# ADmFv9k6FdFpy0RA3Lb9D5lm2oEz69bgk3Y9GiUdZG+Af/N7a72jii1CBbf8rIHn
# jWSfdb39e/EwFELonx9vRWLf6HZJWDgUmq+b0JdGbqoMl0zoPSJgvTwKuQITXvaz
# Z0EWpCK74PvjgwoQf629s3Ym+l+M6oN1x7fo0n843YXc3jqnMz56Cg/ABMJB1Asu
# Q8iN4pL24Jud5BtF1RHNWY3biDRovtx8EC98EmHJ/BySsHuJCECpNTRk+gzdizRw
# E8Zt4BUpRPr6KKFlSGUEADMl3ccq6CrXphO0VNGHivN/vI3J0jbabCodj/5RGy0e
# gaBtNNQiXABYM4qcjex9rj0=
# SIG # End signature block
