@{
	#Copyright [2017] [Chase Bradley]
    #
	#Licensed under the Apache License, Version 2.0 (the "License");
	#you may not use this file except in compliance with the License.
	#You may obtain a copy of the License at
    #
	#	http://www.apache.org/licenses/LICENSE-2.0
    #
	#Unless required by applicable law or agreed to in writing, software
	#distributed under the License is distributed on an "AS IS" BASIS,
	#WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	#See the License for the specific language governing permissions and
	#limitations under the License.
}

#Test to see if we are in Dev Mode
if($PSScriptRoot -eq ""){
    $current_path = "C:\Temp\grppolicies";
}
else{
    #Only works if running from the file
    $current_path = $PSScriptRoot;
} 

#Import Library
$modulePath = $current_path + "\Import_Types.psm1";
$module = Import-Module $modulePath -ErrorAction Stop -PassThru -Force 

#These are the designated folders to process the .CSV files
$cache = $current_path + "\Policies\Cache";
$inProgress = $current_path + "\Policies\InProgress";
$installed = $current_path + "\Policies\Installed";

#Configure supported file types
$supportedFileTypes = "zip;csv"; #Right now it only supports CSVs from the export and Zip files containing the exports - 
								 #Eventually want to add txt;reg; 
$supportedFileTypes = $supportedFileTypes.split(";");


#MAIN THREAD
$processZip = 0;
$fileType = "csv";
$filePathSet = $cache + "\*." + $fileType;
$files = Get-ChildItem $filePathSet;
ForEach ($file in $files) { 
	if($fileType -eq "zip"){
		Unzip $file $inProgress
		Remove-Item $file
	}
	else{
		Move-Item $file $inProgress
	}
}

$processing = Get-ChildItem $inProgress -Recurse | Select-Object FullName
ForEach ($policyFile in $processing) { 
	$policyFile = $policyFile.FullName;
    $parse = Import_From_CSV($policyFile);
    if($parse -eq 1){
        Move-Item $policyFile $installed
    }
}

#Force GPUpdates
Update-GptIniVersion -Path C:\Windows\System32\GroupPolicy\gpt.ini -PolicyType Machine,User
GPUpdate.exe /force