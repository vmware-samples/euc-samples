@{
	#Copyright [2017] [Chase Bradley]
    #
	#Licensed under the Apache License, Version 2.0 (the "License");
	#you may not use this file except in compliance with the License.
	#You may obtain a copy of the License at
    #
	#	http://www.apache.org/licenses/LICENSE-2.0
    #
	#Unless required by applicable law or agreed to in writing, software
	#distributed under the License is distributed on an "AS IS" BASIS,
	#WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	#See the License for the specific language governing permissions and
	#limitations under the License.*/
}

#Test to see if we are in Dev Mode
if($PSScriptRoot -eq ""){
    $current_path = "C:\Temp\grppolicies";
}
else{
    #Only works if running from the file
    $current_path = $PSScriptRoot;
} 

$modulePath = $current_path + "\includes\PolicyFileEditor.psd1"
#Initialize Policy File Editor 
$module = Import-Module $modulePath -ErrorAction Stop -PassThru -Force 

function Import_From_CSV
{
	param([string]$policyFile)
	
	#Default paths for the registry.pol file
    $MachinePath = "$env:systemroot\system32\GroupPolicy\Machine\registry.pol";
    $UserPath = "$env:systemroot\system32\GroupPolicy\User\registry.pol";
	
	#Import CSV file
	$policies = Get-Content $policyFile;
    $results = 1;
    
    ForEach($line in $policies){
        $items = $line.Split(",");
        $PolPath = "";
        if($items[0] -eq "Machine"){
            $PolPath = $MachinePath;
        } elseif ($items[0] -eq "User"){
            $PolPath = $UserPath;
        }
        if($PolPath){
            $type = $items[1];
            $key = $items[2];
            $valueName = $items[3];
            $data = $items[4];
            Try{
				#Policy File command from imported .POL file library
                Set-PolicyFileEntry -Path $PolPath -Key $key -ValueName $valueName -Data $data -Type $type >> "output.txt";
            } Catch{
                $results = 0;
            }
        }
    }
    return $results;
}

#Initialize Zip processes
Add-Type -AssemblyName System.IO.Compression.FileSystem
function Unzip
{
    param([string]$zipfile, [string]$outpath)

    [System.IO.Compression.ZipFile]::ExtractToDirectory($zipfile, $outpath)
}